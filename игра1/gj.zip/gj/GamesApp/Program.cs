﻿using System;
using System.Linq;
using System.Text;
using GamesData;
using GamesModels;

namespace GamesApp
{
    internal class Program
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;

            using (var db = new GamesContext())
            {
                if (!db.Games.Any())
                {
                    db.Games.Add(new Game
                    {
                        Title = "Minecraft",
                        Studio = "Mojang",
                        Genre = "Sandbox",
                        ReleaseDate = new DateTime(2011, 11, 18)
                    });

                    db.Games.Add(new Game
                    {
                        Title = "Portal 2",
                        Studio = "Valve",
                        Genre = "Puzzle",
                        ReleaseDate = new DateTime(2011, 4, 19)
                    });

                    db.Games.Add(new Game
                    {
                        Title = "Terraria",
                        Studio = "Re-Logic",
                        Genre = "Sandbox",
                        ReleaseDate = new DateTime(2011, 5, 16)
                    });

                    db.SaveChanges();
                }

                // Условные значения для учебного примера.
                var minecraft = db.Games.First(g => g.Title == "Minecraft");
                minecraft.Mode = GameMode.Multiplayer;
                minecraft.SoldCopies = 300;

                var portal = db.Games.First(g => g.Title == "Portal 2");
                portal.Mode = GameMode.SinglePlayer;
                portal.SoldCopies = 100;

                var terraria = db.Games.First(g => g.Title == "Terraria");
                terraria.Mode = GameMode.Multiplayer;
                terraria.SoldCopies = 200;

                db.SaveChanges();

                Console.WriteLine("База: " + db.Database.Connection.Database);
                Console.WriteLine("\nСписок игр:");

                foreach (var game in db.Games.OrderBy(g => g.Title).ToList())
                {
                    string mode = game.Mode == GameMode.SinglePlayer
                        ? "Однопользовательская"
                        : "Многопользовательская";

                    Console.WriteLine(
                        $"{game.Id}. {game.Title} | {game.Studio} | " +
                        $"{game.Genre} | {game.ReleaseDate:dd.MM.yyyy} | " +
                        $"{mode} | Продано: {game.SoldCopies}");
                }
            }

            Console.WriteLine("\nНажми Enter для выхода.");
            Console.ReadLine();
        }
    }
}