﻿namespace GamesData.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddModeAndSoldCopies : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Games", "Mode", c => c.Int(nullable: false));
            AddColumn("dbo.Games", "SoldCopies", c => c.Long(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Games", "SoldCopies");
            DropColumn("dbo.Games", "Mode");
        }
    }
}
