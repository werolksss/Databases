﻿using System.Data.Entity;
using GamesModels;

namespace GamesData
{
    public class GamesContext : DbContext
    {
        public GamesContext() : base("name=GamesDb")
        {
        }

        public DbSet<Game> Games { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Game>()
                .Property(g => g.Title).IsRequired().HasMaxLength(150);

            modelBuilder.Entity<Game>()
                .Property(g => g.Studio).IsRequired().HasMaxLength(150);

            modelBuilder.Entity<Game>()
                .Property(g => g.Genre).IsRequired().HasMaxLength(80);

            base.OnModelCreating(modelBuilder);
        }
    }
}