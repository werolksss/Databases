﻿using System;

namespace GamesModels
{
    public enum GameMode
    {
        SinglePlayer,
        Multiplayer
    }

    public class Game
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Studio { get; set; }
        public string Genre { get; set; }
        public DateTime ReleaseDate { get; set; }

        public GameMode Mode { get; set; }
        public long SoldCopies { get; set; }
    }
}