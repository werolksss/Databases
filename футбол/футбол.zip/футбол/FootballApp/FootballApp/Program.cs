﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FootballApp
{
    internal class Program
    {
        static string Text(string message)
        {
            while (true)
            {
                Console.Write(message);
                string text = Console.ReadLine();

                if (text == null)
                    throw new OperationCanceledException();

                text = text.Trim();

                if (text.Length > 0 && text.Length <= 150)
                    return text;

                Console.WriteLine("Введи от 1 до 150 символов.");
            }
        }

        static int Number(string message)
        {
            while (true)
            {
                int number;

                if (int.TryParse(Text(message), out number) && number >= 0)
                    return number;

                Console.WriteLine("Введи целое неотрицательное число.");
            }
        }

        static void Show(IEnumerable<Team> teams)
        {
            var list = teams.ToList();

            if (list.Count == 0)
                Console.WriteLine("Команды не найдены.");

            foreach (var team in list)
            {
                Console.WriteLine(
                    $"Id {team.Id}: {team.Name} | {team.City} | " +
                    $"Побед: {team.Wins} | Поражений: {team.Losses} | " +
                    $"Ничьих: {team.Draws} | " +
                    $"Забито: {team.GoalsScored} | " +
                    $"Пропущено: {team.GoalsConceded}");
            }
        }

        static Team ReadTeam()
        {
            return new Team
            {
                Name = Text("Название команды: "),
                City = Text("Город: "),
                Wins = Number("Побед: "),
                Losses = Number("Поражений: "),
                Draws = Number("Ничьих: "),
                GoalsScored = Number("Забито голов: "),
                GoalsConceded = Number("Пропущено голов: ")
            };
        }

        static bool Exists(FootballContext db, Team team, int exceptId = 0)
        {
            string name = team.Name.ToUpperInvariant();
            string city = team.City.ToUpperInvariant();

            return db.Teams.Any(t =>
                t.Id != exceptId &&
                t.Name.ToUpper() == name &&
                t.City.ToUpper() == city);
        }

        static void AddTeam(FootballContext db)
        {
            var team = ReadTeam();

            if (Exists(db, team))
            {
                Console.WriteLine("Такая команда в этом городе уже есть.");
                return;
            }

            db.Teams.Add(team);
            db.SaveChanges();

            Console.WriteLine("Команда добавлена.");
        }

        static void EditTeam(FootballContext db)
        {
            Show(db.Teams.OrderBy(t => t.Id).ToList());

            var team = db.Teams.Find(Number("Id изменяемой команды: "));

            if (team == null)
            {
                Console.WriteLine("Команда не найдена.");
                return;
            }

            Console.WriteLine(
                "Введи новые данные всех полей. " +
                "Для сохранения прежнего значения повтори его.");

            var updated = ReadTeam();

            if (Exists(db, updated, team.Id))
            {
                Console.WriteLine("Другая команда с такими данными уже есть.");
                return;
            }

            team.Name = updated.Name;
            team.City = updated.City;
            team.Wins = updated.Wins;
            team.Losses = updated.Losses;
            team.Draws = updated.Draws;
            team.GoalsScored = updated.GoalsScored;
            team.GoalsConceded = updated.GoalsConceded;

            db.SaveChanges();
            Console.WriteLine("Изменения сохранены.");
        }

        static void DeleteTeam(FootballContext db)
        {
            string name = Text("Название команды: ").ToUpperInvariant();
            string city = Text("Город: ").ToUpperInvariant();

            var team = db.Teams.FirstOrDefault(t =>
                t.Name.ToUpper() == name &&
                t.City.ToUpper() == city);

            if (team == null)
            {
                Console.WriteLine("Команда не найдена.");
                return;
            }

            Show(new[] { team });

            if (!Text("Удалить команду? Введи да: ")
                .Equals("да", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Удаление отменено.");
                return;
            }

            db.Teams.Remove(team);
            db.SaveChanges();

            Console.WriteLine("Команда удалена.");
        }

        static void Seed()
        {
            using (var db = new FootballContext())
            {
                if (db.Teams.Any())
                    return;

                // Статистика условная, для учебной проверки.
                db.Teams.AddRange(new[]
                {
                    new Team
                    {
                        Name = "Real Madrid", City = "Madrid",
                        Wins = 25, Losses = 3, Draws = 10,
                        GoalsScored = 80, GoalsConceded = 30
                    },
                    new Team
                    {
                        Name = "Barcelona", City = "Barcelona",
                        Wins = 24, Losses = 5, Draws = 9,
                        GoalsScored = 85, GoalsConceded = 35
                    },
                    new Team
                    {
                        Name = "Atletico Madrid", City = "Madrid",
                        Wins = 20, Losses = 8, Draws = 10,
                        GoalsScored = 65, GoalsConceded = 40
                    },
                    new Team
                    {
                        Name = "Sevilla", City = "Sevilla",
                        Wins = 12, Losses = 15, Draws = 11,
                        GoalsScored = 45, GoalsConceded = 60
                    }
                });

                db.SaveChanges();
            }
        }

        static void Main()
        {
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            try
            {
                Seed();

                while (true)
                {
                    Console.WriteLine(
                        "\n1. Все команды" +
                        "\n2. Поиск по названию" +
                        "\n3. Поиск по городу" +
                        "\n4. Поиск по названию и городу" +
                        "\n5. Больше всего побед" +
                        "\n6. Больше всего поражений" +
                        "\n7. Больше всего ничьих" +
                        "\n8. Больше всего забитых голов" +
                        "\n9. Больше всего пропущенных голов" +
                        "\n10. Добавить команду" +
                        "\n11. Изменить команду" +
                        "\n12. Удалить команду" +
                        "\n0. Выход");

                    string choice = Text("Выбор: ");

                    if (choice == "0")
                        return;

                    using (var db = new FootballContext())
                    {
                        try
                        {
                            string value;

                            switch (choice)
                            {
                                case "1":
                                    Show(db.Teams
                                        .OrderBy(t => t.Name).ToList());
                                    break;

                                case "2":
                                    value = Text("Название: ");
                                    Show(db.Teams.Where(t =>
                                        t.Name.Contains(value))
                                        .OrderBy(t => t.Name).ToList());
                                    break;

                                case "3":
                                    value = Text("Город: ");
                                    Show(db.Teams.Where(t =>
                                        t.City.Contains(value))
                                        .OrderBy(t => t.Name).ToList());
                                    break;

                                case "4":
                                    value = Text("Название: ");
                                    string city = Text("Город: ");

                                    Show(db.Teams.Where(t =>
                                        t.Name.Contains(value) &&
                                        t.City.Contains(city))
                                        .OrderBy(t => t.Name).ToList());
                                    break;

                                case "5":
                                    Show(db.Teams
                                        .OrderByDescending(t => t.Wins)
                                        .ThenBy(t => t.Id).Take(1).ToList());
                                    break;

                                case "6":
                                    Show(db.Teams
                                        .OrderByDescending(t => t.Losses)
                                        .ThenBy(t => t.Id).Take(1).ToList());
                                    break;

                                case "7":
                                    Show(db.Teams
                                        .OrderByDescending(t => t.Draws)
                                        .ThenBy(t => t.Id).Take(1).ToList());
                                    break;

                                case "8":
                                    Show(db.Teams
                                        .OrderByDescending(t => t.GoalsScored)
                                        .ThenBy(t => t.Id).Take(1).ToList());
                                    break;

                                case "9":
                                    Show(db.Teams
                                        .OrderByDescending(t => t.GoalsConceded)
                                        .ThenBy(t => t.Id).Take(1).ToList());
                                    break;

                                case "10":
                                    AddTeam(db);
                                    break;

                                case "11":
                                    EditTeam(db);
                                    break;

                                case "12":
                                    DeleteTeam(db);
                                    break;

                                default:
                                    Console.WriteLine("Нет такого пункта.");
                                    break;
                            }
                        }
                        catch (OperationCanceledException)
                        {
                            return;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(
                                "Ошибка: " + ex.GetBaseException().Message);
                        }
                    }
                }
            }
            catch (OperationCanceledException)
            {
                return;
            }
            catch (Exception ex)
            {
                Console.WriteLine(
                    "Ошибка запуска: " + ex.GetBaseException().Message);
                Console.ReadLine();
            }
        }
    }
}