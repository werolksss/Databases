﻿using System.Data.Entity;

namespace FootballApp
{
    public class FootballContext : DbContext
    {
        public FootballContext() : base("name=FootballDb")
        {
        }

        public DbSet<Team> Teams { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Team>()
                .Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(150);

            modelBuilder.Entity<Team>()
                .Property(t => t.City)
                .IsRequired()
                .HasMaxLength(150);

            base.OnModelCreating(modelBuilder);
        }
    }
}