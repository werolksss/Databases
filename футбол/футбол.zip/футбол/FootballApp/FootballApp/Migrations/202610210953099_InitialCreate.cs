﻿namespace FootballApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Teams",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 150),
                        City = c.String(nullable: false, maxLength: 150),
                        Wins = c.Int(nullable: false),
                        Losses = c.Int(nullable: false),
                        Draws = c.Int(nullable: false),
                        GoalsScored = c.Int(nullable: false),
                        GoalsConceded = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Teams");
        }
    }
}
