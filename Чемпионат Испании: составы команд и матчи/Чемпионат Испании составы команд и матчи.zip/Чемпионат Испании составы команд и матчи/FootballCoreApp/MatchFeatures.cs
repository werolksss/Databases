﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace FootballCoreApp;

public static class MatchFeatures
{
    // Обновление уже существующей базы без удаления данных.
    public static void UpdateSchema(LeagueContext db)
    {
        db.Database.ExecuteSqlRaw("""
            IF COL_LENGTH('dbo.Players', 'Country') IS NULL
                ALTER TABLE dbo.Players
                ADD Country nvarchar(100) NOT NULL
                    DEFAULT N'Не указана';
            """);

        db.Database.ExecuteSqlRaw("""
            IF COL_LENGTH('dbo.Players', 'Number') IS NULL
                ALTER TABLE dbo.Players
                ADD Number int NOT NULL DEFAULT 0;
            """);

        db.Database.ExecuteSqlRaw("""
            IF COL_LENGTH('dbo.Players', 'Position') IS NULL
                ALTER TABLE dbo.Players
                ADD Position nvarchar(100) NOT NULL
                    DEFAULT N'Не указана';
            """);

        db.Database.ExecuteSqlRaw("""
            IF EXISTS
            (
                SELECT 1
                FROM sys.indexes
                WHERE object_id = OBJECT_ID('dbo.Matches')
                  AND name = N'IX_Matches_HomeTeamId_AwayTeamId'
            )
                DROP INDEX IX_Matches_HomeTeamId_AwayTeamId
                ON dbo.Matches;

            IF NOT EXISTS
            (
                SELECT 1
                FROM sys.indexes
                WHERE object_id = OBJECT_ID('dbo.Matches')
                  AND name = N'UX_Matches_Teams_Date'
            )
                CREATE UNIQUE INDEX UX_Matches_Teams_Date
                ON dbo.Matches
                    (HomeTeamId, AwayTeamId, MatchDate);
            """);
    }

    // Дополняем только учебных игроков из предыдущего задания.
    public static void FillDemoProfiles(LeagueContext db)
    {
        var players = db.Players.OrderBy(p => p.Id).ToList();

        foreach (var group in players.GroupBy(p => p.TeamId))
        {
            var used = new HashSet<int>(
                group.Where(p => p.Number > 0).Select(p => p.Number));

            foreach (var player in group)
            {
                if (!player.FullName.Contains(": Игрок "))
                    continue;

                if (string.IsNullOrWhiteSpace(player.Country)
                    || player.Country == "Не указана")
                {
                    player.Country = "Испания";
                }

                if (player.Number == 0)
                {
                    int number = 1;

                    while (used.Contains(number))
                        number++;

                    player.Number = number;
                    used.Add(number);
                }

                if (string.IsNullOrWhiteSpace(player.Position)
                    || player.Position == "Не указана")
                {
                    player.Position = (player.Number % 3) switch
                    {
                        1 => "Нападающий",
                        2 => "Полузащитник",
                        _ => "Защитник"
                    };
                }
            }
        }

        db.SaveChanges();
    }

    private static string Text(string message)
    {
        while (true)
        {
            Console.Write(message);
            string? value = Console.ReadLine();

            if (value == null)
                throw new OperationCanceledException();

            value = value.Trim();

            if (value.Length > 0 && value.Length <= 150)
                return value;

            Console.WriteLine("Введи от 1 до 150 символов.");
        }
    }

    private static int Number(string message, int max = int.MaxValue)
    {
        while (true)
        {
            if (int.TryParse(Text(message), out int value)
                && value >= 0 && value <= max)
            {
                return value;
            }

            Console.WriteLine(
                $"Нужно целое число от 0 до {max}.");
        }
    }

    private static DateTime ReadDate()
    {
        while (true)
        {
            if (DateTime.TryParseExact(
                Text("Дата матча (дд.мм.гггг): "),
                "dd.MM.yyyy",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out DateTime date))
            {
                return date.Date;
            }

            Console.WriteLine("Неверная дата. Пример: 26.10.2026.");
        }
    }

    private static int ChooseTeam(LeagueContext db, string message)
    {
        var teams = db.Teams.OrderBy(t => t.Id).ToList();

        foreach (var team in teams)
            Console.WriteLine($"{team.Id}. {team.Name}, {team.City}");

        while (true)
        {
            int id = Number(message);

            if (teams.Any(t => t.Id == id))
                return id;

            Console.WriteLine("Команда не найдена.");
        }
    }

    private static int ChoosePlayer(LeagueContext db, int teamId)
    {
        var players = db.Players
            .Where(p => p.TeamId == teamId)
            .OrderBy(p => p.Id)
            .ToList();

        if (players.Count == 0)
            throw new Exception("У команды нет игроков.");

        foreach (var player in players)
        {
            Console.WriteLine(
                $"Id {player.Id}: {player.FullName}, " +
                $"номер {player.Number}, {player.Position}");
        }

        while (true)
        {
            int id = Number("Id автора гола: ");

            if (players.Any(p => p.Id == id))
                return id;

            Console.WriteLine("Выбери игрока именно этой команды.");
        }
    }

    public static void ShowRoster(LeagueContext db)
    {
        int teamId = ChooseTeam(db, "Id команды: ");

        var players = db.Players
            .Where(p => p.TeamId == teamId)
            .OrderBy(p => p.Number)
            .ToList();

        if (players.Count == 0)
            Console.WriteLine("У команды нет игроков.");

        foreach (var player in players)
        {
            Console.WriteLine(
                $"Id {player.Id}: {player.FullName} | " +
                $"Страна: {player.Country} | " +
                $"Номер: {player.Number} | " +
                $"Позиция: {player.Position}");
        }
    }

    public static void ShowDifference(LeagueContext db)
    {
        foreach (var team in db.Standings
            .OrderBy(t => t.TeamName).ToList())
        {
            int difference = team.GoalsScored - team.GoalsConceded;

            Console.WriteLine(
                $"{team.TeamName}: " +
                $"{team.GoalsScored} - {team.GoalsConceded} " +
                $"= {difference}");
        }
    }

    private static void ShowFullMatch(LeagueContext db, Match match)
    {
        string home = db.Teams
            .Where(t => t.Id == match.HomeTeamId)
            .Select(t => t.Name).Single();

        string away = db.Teams
            .Where(t => t.Id == match.AwayTeamId)
            .Select(t => t.Name).Single();

        Console.WriteLine(
            $"\nМатч Id {match.Id} | {match.MatchDate:dd.MM.yyyy}\n" +
            $"{home} {match.HomeGoals}:{match.AwayGoals} {away}");

        var scorers =
            (from goal in db.Goals
             join player in db.Players
                 on goal.PlayerId equals player.Id
             join team in db.Teams
                 on player.TeamId equals team.Id
             where goal.MatchId == match.Id
             group goal by new
             {
                 player.Id,
                 player.FullName,
                 TeamName = team.Name
             }
             into groupGoals
             select new
             {
                 PlayerId = groupGoals.Key.Id,
                 PlayerName = groupGoals.Key.FullName,
                 TeamName = groupGoals.Key.TeamName,
                 Goals = groupGoals.Count()
             })
            .OrderBy(p => p.PlayerId)
            .ToList();

        if (scorers.Count == 0)
            Console.WriteLine("Забитых голов нет.");

        foreach (var scorer in scorers)
        {
            Console.WriteLine(
                $"{scorer.PlayerName} | {scorer.TeamName} | " +
                $"Голов: {scorer.Goals}");
        }
    }

    private static void ShowList(
        LeagueContext db, List<Match> matches)
    {
        if (matches.Count == 0)
            Console.WriteLine("Матчи не найдены.");

        foreach (var match in matches)
            ShowFullMatch(db, match);
    }

    public static void ShowById(LeagueContext db)
    {
        int id = Number("Id матча: ");
        var match = db.Matches.Find(id);

        if (match == null)
        {
            Console.WriteLine("Матч не найден.");
            return;
        }

        ShowFullMatch(db, match);
    }

    public static void ShowByDate(LeagueContext db)
    {
        DateTime date = ReadDate();
        DateTime next = date.AddDays(1);

        ShowList(db, db.Matches
            .Where(m => m.MatchDate >= date && m.MatchDate < next)
            .OrderBy(m => m.Id).ToList());
    }

    public static void ShowByTeam(LeagueContext db)
    {
        int id = ChooseTeam(db, "Id команды: ");

        ShowList(db, db.Matches
            .Where(m => m.HomeTeamId == id || m.AwayTeamId == id)
            .OrderBy(m => m.MatchDate).ToList());
    }

    public static void ShowScorersByDate(LeagueContext db)
    {
        DateTime date = ReadDate();
        DateTime next = date.AddDays(1);

        var rows =
            (from goal in db.Goals
             join match in db.Matches
                 on goal.MatchId equals match.Id
             join player in db.Players
                 on goal.PlayerId equals player.Id
             join team in db.Teams
                 on player.TeamId equals team.Id
             where match.MatchDate >= date && match.MatchDate < next
             group goal by new
             {
                 player.Id,
                 player.FullName,
                 TeamName = team.Name
             }
             into groupGoals
             select new
             {
                 PlayerId = groupGoals.Key.Id,
                 PlayerName = groupGoals.Key.FullName,
                 TeamName = groupGoals.Key.TeamName,
                 Goals = groupGoals.Count()
             })
            .OrderBy(p => p.PlayerId)
            .ToList();

        if (rows.Count == 0)
            Console.WriteLine("В эту дату забитых голов нет.");

        foreach (var row in rows)
        {
            Console.WriteLine(
                $"{row.PlayerName} | {row.TeamName} | " +
                $"Голов за дату: {row.Goals}");
        }
    }

    private sealed class MatchInput
    {
        public int HomeId { get; set; }
        public int AwayId { get; set; }
        public DateTime Date { get; set; }
        public int HomeGoals { get; set; }
        public int AwayGoals { get; set; }
        public List<int> Scorers { get; } = new();
    }

    private static MatchInput ReadMatch(
        LeagueContext db, int exceptId = 0)
    {
        var input = new MatchInput();

        input.HomeId = ChooseTeam(db, "Id команды 1: ");
        input.AwayId = ChooseTeam(db, "Id команды 2: ");

        if (input.HomeId == input.AwayId)
            throw new Exception("Команда не может играть сама с собой.");

        input.Date = ReadDate();
        DateTime next = input.Date.AddDays(1);

        bool exists = db.Matches.Any(m =>
            m.Id != exceptId &&
            m.MatchDate >= input.Date &&
            m.MatchDate < next &&
            (
                (m.HomeTeamId == input.HomeId &&
                 m.AwayTeamId == input.AwayId)
                ||
                (m.HomeTeamId == input.AwayId &&
                 m.AwayTeamId == input.HomeId)
            ));

        if (exists)
            throw new Exception("Матч этих команд в эту дату уже есть.");

        input.HomeGoals = Number("Голов команды 1: ", 20);
        input.AwayGoals = Number("Голов команды 2: ", 20);

        for (int i = 1; i <= input.HomeGoals; i++)
        {
            Console.WriteLine($"\nКоманда 1, автор гола №{i}:");
            input.Scorers.Add(ChoosePlayer(db, input.HomeId));
        }

        for (int i = 1; i <= input.AwayGoals; i++)
        {
            Console.WriteLine($"\nКоманда 2, автор гола №{i}:");
            input.Scorers.Add(ChoosePlayer(db, input.AwayId));
        }

        return input;
    }

    public static void AddMatch(LeagueContext db)
    {
        var input = ReadMatch(db);

        using var transaction = db.Database.BeginTransaction();

        try
        {
            var match = new Match
            {
                HomeTeamId = input.HomeId,
                AwayTeamId = input.AwayId,
                MatchDate = input.Date,
                HomeGoals = input.HomeGoals,
                AwayGoals = input.AwayGoals
            };

            db.Matches.Add(match);
            db.SaveChanges();

            foreach (int playerId in input.Scorers)
            {
                db.Goals.Add(new Goal
                {
                    MatchId = match.Id,
                    PlayerId = playerId
                });
            }

            db.SaveChanges();
            transaction.Commit();

            Console.WriteLine($"Матч добавлен. Id = {match.Id}");
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    public static void EditMatch(LeagueContext db)
    {
        int id = Number("Id изменяемого матча: ");
        var match = db.Matches.Find(id);

        if (match == null)
        {
            Console.WriteLine("Матч не найден.");
            return;
        }

        ShowFullMatch(db, match);

        Console.WriteLine(
            "\nВведи новые команды, дату, счёт и авторов голов. " +
            "Чтобы оставить значение прежним, повтори его.");

        var input = ReadMatch(db, id);

        using var transaction = db.Database.BeginTransaction();

        try
        {
            var oldGoals = db.Goals
                .Where(g => g.MatchId == id).ToList();

            db.Goals.RemoveRange(oldGoals);

            match.HomeTeamId = input.HomeId;
            match.AwayTeamId = input.AwayId;
            match.MatchDate = input.Date;
            match.HomeGoals = input.HomeGoals;
            match.AwayGoals = input.AwayGoals;

            foreach (int playerId in input.Scorers)
            {
                db.Goals.Add(new Goal
                {
                    MatchId = match.Id,
                    PlayerId = playerId
                });
            }

            db.SaveChanges();
            transaction.Commit();

            Console.WriteLine("Матч изменён.");
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    public static void DeleteMatch(LeagueContext db)
    {
        string homeName = Text("Название команды 1: ")
            .ToUpperInvariant();

        string awayName = Text("Название команды 2: ")
            .ToUpperInvariant();

        DateTime date = ReadDate();
        DateTime next = date.AddDays(1);

        var matches =
            (from match in db.Matches
             join home in db.Teams
                 on match.HomeTeamId equals home.Id
             join away in db.Teams
                 on match.AwayTeamId equals away.Id
             where match.MatchDate >= date && match.MatchDate < next
             where
                (home.Name.ToUpper() == homeName &&
                 away.Name.ToUpper() == awayName)
                ||
                (home.Name.ToUpper() == awayName &&
                 away.Name.ToUpper() == homeName)
             select match)
            .ToList();

        if (matches.Count == 0)
        {
            Console.WriteLine("Матч не найден.");
            return;
        }

        if (matches.Count > 1)
            throw new Exception("Найдено несколько подходящих матчей.");

        var found = matches[0];
        ShowFullMatch(db, found);

        if (!Text("Удалить матч? Введи да: ")
            .Equals("да", StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine("Удаление отменено.");
            return;
        }

        using var transaction = db.Database.BeginTransaction();

        try
        {
            db.Goals.RemoveRange(
                db.Goals.Where(g => g.MatchId == found.Id).ToList());

            db.Matches.Remove(found);
            db.SaveChanges();

            transaction.Commit();
            Console.WriteLine("Матч удалён вместе с записями о голах.");
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }
}