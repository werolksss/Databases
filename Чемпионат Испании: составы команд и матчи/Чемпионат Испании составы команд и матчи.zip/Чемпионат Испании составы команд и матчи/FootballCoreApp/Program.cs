﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace FootballCoreApp;

internal class Program
{
    private static void ShowScorers(IEnumerable<ScorerRow> source)
    {
        var rows = source.ToList();

        if (rows.Count == 0)
            Console.WriteLine("Игроков с забитыми голами пока нет.");

        foreach (var row in rows)
        {
            Console.WriteLine(
                $"{row.PlayerName} | {row.TeamName} | " +
                $"Голов: {row.Goals}");
        }
    }

    private static void ShowTeams(IEnumerable<TeamRow> source)
    {
        foreach (var row in source)
        {
            Console.WriteLine(
                $"{row.TeamName} | Побед: {row.Wins} | " +
                $"Поражений: {row.Losses} | Ничьих: {row.Draws} | " +
                $"Забито: {row.GoalsScored} | " +
                $"Пропущено: {row.GoalsConceded} | " +
                $"Очков: {row.Points}");
        }
    }

    private static int? ChooseTeam(LeagueContext db)
    {
        foreach (var team in db.Teams.OrderBy(t => t.Id).ToList())
            Console.WriteLine($"{team.Id}. {team.Name}");

        Console.Write("Id команды: ");

        if (int.TryParse(Console.ReadLine(), out int id)
            && db.Teams.Any(t => t.Id == id))
            return id;

        Console.WriteLine("Команда не найдена.");
        return null;
    }

    private static void ShowMatches(LeagueContext db)
    {
        var teams = db.Teams.ToDictionary(t => t.Id, t => t.Name);

        var matches = db.Matches
            .OrderBy(m => m.MatchDate)
            .ThenBy(m => m.Id)
            .ToList();

        if (matches.Count == 0)
            Console.WriteLine("Матчей пока нет.");

        foreach (var match in matches)
        {
            Console.WriteLine(
                $"Id {match.Id} | {match.MatchDate:dd.MM.yyyy}: " +
                $"{teams[match.HomeTeamId]} " +
                $"{match.HomeGoals}:{match.AwayGoals} " +
                $"{teams[match.AwayTeamId]}");
        }
    }

    private static void Main()
    {
        Console.InputEncoding = Encoding.UTF8;
        Console.OutputEncoding = Encoding.UTF8;

        try
        {
            using (var db = new LeagueContext())
            {
                db.Database.EnsureCreated();

                MatchFeatures.UpdateSchema(db);
                SqlObjects.Create(db);

                LeagueService.Seed(db);
                MatchFeatures.FillDemoProfiles(db);
            }

            while (true)
            {
                Console.WriteLine(
                    "\n1. Заполнить матчи случайным образом" +
                    "\n2. Топ-3 бомбардиров команды" +
                    "\n3. Лучший бомбардир команды" +
                    "\n4. Топ-3 бомбардиров чемпионата" +
                    "\n5. Лучший бомбардир чемпионата" +
                    "\n6. Топ-3 команд по забитым голам" +
                    "\n7. Команда с максимумом забитых голов" +
                    "\n8. Топ-3 команд с минимумом пропущенных" +
                    "\n9. Команда с минимумом пропущенных" +
                    "\n10. Топ-3 команд по максимуму очков" +
                    "\n11. Команда с максимумом очков" +
                    "\n12. Топ-3 команд по минимуму очков" +
                    "\n13. Команда с минимумом очков" +
                    "\n14. Краткий список матчей" +
                    "\n15. Тесты предыдущего задания" +
                    "\n16. Разница забитых и пропущенных голов" +
                    "\n17. Полная информация о матче" +
                    "\n18. Матчи в конкретную дату" +
                    "\n19. Все матчи команды" +
                    "\n20. Игроки, забившие голы в конкретную дату" +
                    "\n21. Добавить матч" +
                    "\n22. Изменить матч" +
                    "\n23. Удалить матч" +
                    "\n24. Состав команды" +
                    "\n0. Выход");

                Console.Write("Выбор: ");
                string? choice = Console.ReadLine();

                if (choice == null || choice == "0")
                    return;

                try
                {
                    using var db = new LeagueContext();

                    switch (choice)
                    {
                        case "1":
                            LeagueService.Generate(db, DateTime.Today);
                            Console.WriteLine(
                                $"Всего матчей: {db.Matches.Count()}");
                            break;

                        case "2":
                        case "3":
                            {
                                int? id = ChooseTeam(db);

                                if (id.HasValue)
                                {
                                    ShowScorers(LeagueService.BestScorers(
                                        db, choice == "2" ? 3 : 1, id.Value));
                                }

                                break;
                            }

                        case "4":
                            ShowScorers(
                                LeagueService.BestScorers(db, 3));
                            break;

                        case "5":
                            ShowScorers(
                                LeagueService.BestScorers(db, 1));
                            break;

                        case "6":
                            ShowTeams(
                                LeagueService.MostGoals(db, 3));
                            break;

                        case "7":
                            ShowTeams(
                                LeagueService.MostGoals(db, 1));
                            break;

                        case "8":
                            ShowTeams(
                                LeagueService.FewestConceded(db, 3));
                            break;

                        case "9":
                            ShowTeams(
                                LeagueService.FewestConceded(db, 1));
                            break;

                        case "10":
                            ShowTeams(
                                LeagueService.Points(db, 3, true));
                            break;

                        case "11":
                            ShowTeams(
                                LeagueService.Points(db, 1, true));
                            break;

                        case "12":
                            ShowTeams(
                                LeagueService.Points(db, 3, false));
                            break;

                        case "13":
                            ShowTeams(
                                LeagueService.Points(db, 1, false));
                            break;

                        case "14":
                            ShowMatches(db);
                            break;

                        case "15":
                            Console.WriteLine(DbTests.Run().Text);
                            break;

                        case "16":
                            MatchFeatures.ShowDifference(db);
                            break;

                        case "17":
                            MatchFeatures.ShowById(db);
                            break;

                        case "18":
                            MatchFeatures.ShowByDate(db);
                            break;

                        case "19":
                            MatchFeatures.ShowByTeam(db);
                            break;

                        case "20":
                            MatchFeatures.ShowScorersByDate(db);
                            break;

                        case "21":
                            MatchFeatures.AddMatch(db);
                            break;

                        case "22":
                            MatchFeatures.EditMatch(db);
                            break;

                        case "23":
                            MatchFeatures.DeleteMatch(db);
                            break;

                        case "24":
                            MatchFeatures.ShowRoster(db);
                            break;

                        default:
                            Console.WriteLine("Выбери пункт от 0 до 24.");
                            break;
                    }
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(
                        "Ошибка: " + ex.GetBaseException().Message);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                "Ошибка запуска: " + ex.GetBaseException().Message);
            Console.ReadLine();
        }
    }
}