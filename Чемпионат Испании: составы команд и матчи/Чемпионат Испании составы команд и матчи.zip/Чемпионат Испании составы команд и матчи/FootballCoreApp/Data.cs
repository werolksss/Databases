﻿using System;
using Microsoft.EntityFrameworkCore;

namespace FootballCoreApp;

public class Team
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string City { get; set; } = "";
}

public class Player
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Country { get; set; } = "";
    public int Number { get; set; }
    public string Position { get; set; } = "";
    public int TeamId { get; set; }
}

public class Match
{
    public int Id { get; set; }
    public int HomeTeamId { get; set; }
    public int AwayTeamId { get; set; }
    public DateTime MatchDate { get; set; }
    public int HomeGoals { get; set; }
    public int AwayGoals { get; set; }
}

public class Goal
{
    public int Id { get; set; }
    public int MatchId { get; set; }
    public int PlayerId { get; set; }
}

// Строка представления с бомбардирами.
public class ScorerRow
{
    public int PlayerId { get; set; }
    public int TeamId { get; set; }
    public string PlayerName { get; set; } = "";
    public string TeamName { get; set; } = "";
    public int Goals { get; set; }
}

// Строка представления со статистикой команд.
public class TeamRow
{
    public int TeamId { get; set; }
    public string TeamName { get; set; } = "";
    public string City { get; set; } = "";
    public int Wins { get; set; }
    public int Losses { get; set; }
    public int Draws { get; set; }
    public int GoalsScored { get; set; }
    public int GoalsConceded { get; set; }
    public int Points { get; set; }
}

public class LeagueContext : DbContext
{
    private readonly string databaseName;

    public LeagueContext(string databaseName = "FootballCoreDb")
    {
        this.databaseName = databaseName;
    }

    public DbSet<Team> Teams => Set<Team>();
    public DbSet<Player> Players => Set<Player>();
    public DbSet<Match> Matches => Set<Match>();
    public DbSet<Goal> Goals => Set<Goal>();

    public DbSet<ScorerRow> Scorers => Set<ScorerRow>();
    public DbSet<TeamRow> Standings => Set<TeamRow>();

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        options.UseSqlServer(
            $"Server=localhost;Database={databaseName};" +
            "Integrated Security=True;TrustServerCertificate=True");
    }

    protected override void OnModelCreating(ModelBuilder model)
    {
        model.Entity<Team>()
            .Property(t => t.Name).HasMaxLength(150);

        model.Entity<Team>()
            .Property(t => t.City).HasMaxLength(150);

        model.Entity<Player>()
            .Property(p => p.FullName).HasMaxLength(150);

        model.Entity<Player>()
            .HasOne<Team>().WithMany()
            .HasForeignKey(p => p.TeamId)
            .OnDelete(DeleteBehavior.Restrict);

        model.Entity<Match>()
            .HasOne<Team>().WithMany()
            .HasForeignKey(m => m.HomeTeamId)
            .OnDelete(DeleteBehavior.Restrict);

        model.Entity<Match>()
            .HasOne<Team>().WithMany()
            .HasForeignKey(m => m.AwayTeamId)
            .OnDelete(DeleteBehavior.Restrict);

        model.Entity<Match>()
            .HasIndex(m => new
            {
                m.HomeTeamId,
                m.AwayTeamId,
                m.MatchDate
            })
            .IsUnique()
            .HasDatabaseName("UX_Matches_Teams_Date");

        model.Entity<Goal>()
            .HasOne<Match>().WithMany()
            .HasForeignKey(g => g.MatchId)
            .OnDelete(DeleteBehavior.Restrict);

        model.Entity<Goal>()
            .HasOne<Player>().WithMany()
            .HasForeignKey(g => g.PlayerId)
            .OnDelete(DeleteBehavior.Restrict);

        model.Entity<ScorerRow>()
            .HasNoKey().ToView("ScorerStats");

        model.Entity<TeamRow>()
            .HasNoKey().ToView("TeamStats");
    }
}