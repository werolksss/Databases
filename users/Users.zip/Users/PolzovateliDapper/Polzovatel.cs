﻿namespace PolzovateliDapper
{
    // свойства соответствуют столбцам таблицы users
    public class Polzovatel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
    }
}