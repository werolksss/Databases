﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Dapper;
using Microsoft.Data.SqlClient;

namespace PolzovateliDapper
{
    class Program
    {
        static readonly string stroka =
            "Server=localhost;Database=TestDB;" +
            "Integrated Security=True;TrustServerCertificate=True;";

        static string Tekst(string vopros)
        {
            Console.Write(vopros);
            string tekst = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(tekst))
                throw new Exception("Введите непустое значение.");

            tekst = tekst.Trim();

            if (tekst.Length > 100)
                throw new Exception("Можно ввести до 100 символов.");

            return tekst;
        }

        static int Chislo(string vopros, int minimum, int maksimum)
        {
            string tekst = Tekst(vopros);

            if (!int.TryParse(tekst, out int chislo) ||
                chislo < minimum || chislo > maksimum)
            {
                throw new Exception(
                    $"Введите целое число от {minimum} до {maksimum}.");
            }

            return chislo;
        }

        static void Vyvesti(Polzovatel chelovek)
        {
            Console.WriteLine(
                $"{chelovek.Id}. {chelovek.Name}, " +
                $"{chelovek.Email}, возраст: {chelovek.Age}");
        }

        static void Dobavit(IDbConnection baza)
        {
            var chelovek = new Polzovatel
            {
                Name = Tekst("Имя и фамилия: "),
                Email = Tekst("Email: "),
                Age = Chislo("Возраст: ", 0, 120)
            };

            // свойства объекта становятся параметрами запроса
            int kolichestvo = baza.Execute(
                @"INSERT INTO Users (Name, Email, Age)
                  VALUES (@Name, @Email, @Age)",
                chelovek);

            Console.WriteLine($"Добавлено записей: {kolichestvo}.");
        }

        static void Pokazat(IDbConnection baza)
        {
            // dapper превращает строки в объекты
            var polzovateli = baza.Query<Polzovatel>(
                "SELECT Id, Name, Email, Age FROM Users ORDER BY Id")
                .ToList();

            if (polzovateli.Count == 0)
                Console.WriteLine("Пользователей пока нет.");

            foreach (var chelovek in polzovateli)
                Vyvesti(chelovek);
        }

        static void Starshe25(IDbConnection baza)
        {
            var polzovateli = baza.Query<Polzovatel>(
                @"SELECT Id, Name, Email, Age
                  FROM Users
                  WHERE Age > @vozrast
                  ORDER BY Id",
                new { vozrast = 25 })
                .ToList();

            if (polzovateli.Count == 0)
                Console.WriteLine("Нет пользователей старше 25 лет.");

            foreach (var chelovek in polzovateli)
                Vyvesti(chelovek);
        }

        static void Izmenit(IDbConnection baza)
        {
            int id = Chislo("ID пользователя: ", 1, int.MaxValue);
            int vozrast = Chislo("Новый возраст: ", 0, 120);

            // меняем возраст выбранного пользователя
            int kolichestvo = baza.Execute(
                "UPDATE Users SET Age = @vozrast WHERE Id = @id",
                new { vozrast, id });

            Console.WriteLine(kolichestvo > 0
                ? "Возраст изменён."
                : "Пользователь не найден.");
        }

        static void Udalit(IDbConnection baza)
        {
            int id = Chislo("ID пользователя: ", 1, int.MaxValue);

            int kolichestvo = baza.Execute(
                "DELETE FROM Users WHERE Id = @id",
                new { id });

            Console.WriteLine(kolichestvo > 0
                ? "Пользователь удалён."
                : "Пользователь не найден.");
        }

        static void Nayti(IDbConnection baza)
        {
            int id = Chislo("ID пользователя: ", 1, int.MaxValue);

            // если записи нет, получим null
            var chelovek = baza.QueryFirstOrDefault<Polzovatel>(
                "SELECT Id, Name, Email, Age FROM Users WHERE Id = @id",
                new { id });

            if (chelovek == null)
                Console.WriteLine("Пользователь не найден.");
            else
                Vyvesti(chelovek);
        }

        static void Main()
        {
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            while (true)
            {
                Console.WriteLine("\nПОЛЬЗОВАТЕЛИ");
                Console.WriteLine("1 — добавить");
                Console.WriteLine("2 — показать всех");
                Console.WriteLine("3 — показать старше 25 лет");
                Console.WriteLine("4 — изменить возраст");
                Console.WriteLine("5 — удалить");
                Console.WriteLine("6 — найти по ID");
                Console.WriteLine("0 — выход");
                Console.Write("Выбор: ");

                string vybor = Console.ReadLine();

                if (vybor == "0" || vybor == null)
                    return;

                try
                {
                    // using освободит соединение даже при ошибке
                    using (IDbConnection baza = new SqlConnection(stroka))
                    {
                        baza.Open();

                        switch (vybor)
                        {
                            case "1":
                                Dobavit(baza);
                                break;

                            case "2":
                                Pokazat(baza);
                                break;

                            case "3":
                                Starshe25(baza);
                                break;

                            case "4":
                                Izmenit(baza);
                                break;

                            case "5":
                                Udalit(baza);
                                break;

                            case "6":
                                Nayti(baza);
                                break;

                            default:
                                Console.WriteLine("Нет такого пункта.");
                                break;
                        }
                    }
                }
                catch (Exception oshibka)
                {
                    Console.WriteLine("Ошибка: " + oshibka.Message);
                }
            }
        }
    }
}