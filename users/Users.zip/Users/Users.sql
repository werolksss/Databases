IF DB_ID(N'TestDB') IS NULL
    CREATE DATABASE TestDB;
GO

USE TestDB;
GO

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE Users
    (
        Id int IDENTITY(1, 1) PRIMARY KEY,
        Name nvarchar(100) NOT NULL,
        Email nvarchar(100) NOT NULL,
        Age int NOT NULL CHECK (Age BETWEEN 0 AND 120)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM Users)
BEGIN
    INSERT INTO Users (Name, Email, Age)
    VALUES
        (N'Анна Иванова', N'anna@mail.ru', 20),
        (N'Иван Петров', N'ivan@mail.ru', 30),
        (N'Мария Смирнова', N'maria@mail.ru', 27),
        (N'Олег Орлов', N'oleg@mail.ru', 24),
        (N'Елена Волкова', N'elena@mail.ru', 35);
END;
GO

SELECT Id, Name, Email, Age FROM Users;