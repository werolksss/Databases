﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using GamesData;
using GamesModels;

namespace GamesApp
{
    internal class Program
    {
        static string Text(string message, int max = 150)
        {
            while (true)
            {
                Console.Write(message);
                string value = Console.ReadLine();

                if (value == null)
                    throw new OperationCanceledException();

                value = value.Trim();

                if (value.Length > 0 && value.Length <= max)
                    return value;

                Console.WriteLine($"Введи от 1 до {max} символов.");
            }
        }

        static long Number(string message, long max = long.MaxValue)
        {
            while (true)
            {
                long value;

                if (long.TryParse(Text(message), out value)
                    && value >= 0 && value <= max)
                    return value;

                Console.WriteLine($"Нужно целое число от 0 до {max}.");
            }
        }

        static DateTime ReadDate()
        {
            while (true)
            {
                DateTime date;

                if (DateTime.TryParseExact(
                    Text("Дата релиза (дд.мм.гггг): "),
                    "dd.MM.yyyy",
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out date) && date.Year >= 1753)
                    return date;

                Console.WriteLine("Неверная дата. Пример: 18.11.2011.");
            }
        }

        static void Show(IEnumerable<Game> games)
        {
            var list = games.ToList();

            if (list.Count == 0)
                Console.WriteLine("Игры не найдены.");

            foreach (var game in list)
            {
                string mode = game.Mode == GameMode.SinglePlayer
                    ? "Однопользовательская"
                    : "Многопользовательская";

                Console.WriteLine(
                    $"Id {game.Id}: {game.Title} | {game.Studio} | " +
                    $"{game.Genre} | {game.ReleaseDate:dd.MM.yyyy} | " +
                    $"{mode} | Продано: {game.SoldCopies}");
            }
        }

        static Game ReadGame()
        {
            var game = new Game();

            game.Title = Text("Название игры: ");
            game.Studio = Text("Студия: ");
            game.Genre = Text("Стиль: ", 80);
            game.ReleaseDate = ReadDate();

            Console.WriteLine(
                "0 — однопользовательская, 1 — многопользовательская");

            game.Mode = (GameMode)Number("Режим: ", 1);
            game.SoldCopies = Number("Продано копий: ");

            return game;
        }

        static bool Exists(GamesContext db, Game game, int exceptId = 0)
        {
            string title = game.Title.ToUpperInvariant();
            string studio = game.Studio.ToUpperInvariant();

            return db.Games.Any(g =>
                g.Id != exceptId &&
                g.Title.ToUpper() == title &&
                g.Studio.ToUpper() == studio);
        }

        static void AddGame(GamesContext db)
        {
            var game = ReadGame();

            if (Exists(db, game))
            {
                Console.WriteLine("Такая игра этой студии уже существует.");
                return;
            }

            db.Games.Add(game);
            db.SaveChanges();

            Console.WriteLine("Игра добавлена.");
        }

        static void EditGame(GamesContext db)
        {
            Show(db.Games.OrderBy(g => g.Id).ToList());

            int id = (int)Number("Id изменяемой игры: ", int.MaxValue);
            var game = db.Games.Find(id);

            if (game == null)
            {
                Console.WriteLine("Игра не найдена.");
                return;
            }

            Console.WriteLine(
                "Введи новые значения всех полей. " +
                "Чтобы сохранить прежнее значение, повтори его.");

            var updated = ReadGame();

            if (Exists(db, updated, id))
            {
                Console.WriteLine(
                    "Другая игра с таким названием и студией уже есть.");
                return;
            }

            game.Title = updated.Title;
            game.Studio = updated.Studio;
            game.Genre = updated.Genre;
            game.ReleaseDate = updated.ReleaseDate;
            game.Mode = updated.Mode;
            game.SoldCopies = updated.SoldCopies;

            db.SaveChanges();
            Console.WriteLine("Изменения сохранены.");
        }

        static void DeleteGame(GamesContext db)
        {
            string title = Text("Название игры: ").ToUpperInvariant();
            string studio = Text("Студия: ").ToUpperInvariant();

            var game = db.Games.FirstOrDefault(g =>
                g.Title.ToUpper() == title &&
                g.Studio.ToUpper() == studio);

            if (game == null)
            {
                Console.WriteLine("Игра не найдена.");
                return;
            }

            Show(new[] { game });

            if (!Text("Удалить игру? Введи да: ")
                .Equals("да", StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Удаление отменено.");
                return;
            }

            db.Games.Remove(game);
            db.SaveChanges();

            Console.WriteLine("Игра удалена.");
        }

        static void Main()
        {
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            try
            {
                while (true)
                {
                    Console.WriteLine(
                        "\n1. Все игры" +
                        "\n2. Поиск по названию" +
                        "\n3. Поиск по студии" +
                        "\n4. Поиск по студии и названию" +
                        "\n5. Поиск по стилю" +
                        "\n6. Поиск по году релиза" +
                        "\n7. Однопользовательские игры" +
                        "\n8. Многопользовательские игры" +
                        "\n9. Игра с максимальными продажами" +
                        "\n10. Игра с минимальными продажами" +
                        "\n11. Топ-3 самых продаваемых" +
                        "\n12. Топ-3 наименее продаваемых" +
                        "\n13. Добавить игру" +
                        "\n14. Изменить игру" +
                        "\n15. Удалить игру" +
                        "\n0. Выход");

                    string choice = Text("Выбор: ");

                    if (choice == "0")
                        return;

                    using (var db = new GamesContext())
                    {
                        try
                        {
                            string value;

                            switch (choice)
                            {
                                case "1":
                                    Show(db.Games.OrderBy(g => g.Title).ToList());
                                    break;

                                case "2":
                                    value = Text("Название: ");
                                    Show(db.Games.Where(g =>
                                        g.Title.Contains(value))
                                        .OrderBy(g => g.Title).ToList());
                                    break;

                                case "3":
                                    value = Text("Студия: ");
                                    Show(db.Games.Where(g =>
                                        g.Studio.Contains(value))
                                        .OrderBy(g => g.Title).ToList());
                                    break;

                                case "4":
                                    value = Text("Студия: ");
                                    string title = Text("Название: ");

                                    Show(db.Games.Where(g =>
                                        g.Studio.Contains(value) &&
                                        g.Title.Contains(title))
                                        .OrderBy(g => g.Title).ToList());
                                    break;

                                case "5":
                                    value = Text("Стиль: ");
                                    Show(db.Games.Where(g =>
                                        g.Genre.Contains(value))
                                        .OrderBy(g => g.Title).ToList());
                                    break;

                                case "6":
                                    int year = (int)Number("Год: ", 9999);
                                    Show(db.Games.Where(g =>
                                        g.ReleaseDate.Year == year)
                                        .OrderBy(g => g.Title).ToList());
                                    break;

                                case "7":
                                    Show(db.Games.Where(g =>
                                        g.Mode == GameMode.SinglePlayer)
                                        .OrderBy(g => g.Title).ToList());
                                    break;

                                case "8":
                                    Show(db.Games.Where(g =>
                                        g.Mode == GameMode.Multiplayer)
                                        .OrderBy(g => g.Title).ToList());
                                    break;

                                case "9":
                                    Show(db.Games
                                        .OrderByDescending(g => g.SoldCopies)
                                        .ThenBy(g => g.Id).Take(1).ToList());
                                    break;

                                case "10":
                                    Show(db.Games
                                        .OrderBy(g => g.SoldCopies)
                                        .ThenBy(g => g.Id).Take(1).ToList());
                                    break;

                                case "11":
                                    Show(db.Games
                                        .OrderByDescending(g => g.SoldCopies)
                                        .ThenBy(g => g.Id).Take(3).ToList());
                                    break;

                                case "12":
                                    Show(db.Games
                                        .OrderBy(g => g.SoldCopies)
                                        .ThenBy(g => g.Id).Take(3).ToList());
                                    break;

                                case "13":
                                    AddGame(db);
                                    break;

                                case "14":
                                    EditGame(db);
                                    break;

                                case "15":
                                    DeleteGame(db);
                                    break;

                                default:
                                    Console.WriteLine("Нет такого пункта.");
                                    break;
                            }
                        }
                        catch (OperationCanceledException)
                        {
                            return;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(
                                "Ошибка: " + ex.GetBaseException().Message);
                        }
                    }
                }
            }
            catch (OperationCanceledException)
            {
                return;
            }
        }
    }
}