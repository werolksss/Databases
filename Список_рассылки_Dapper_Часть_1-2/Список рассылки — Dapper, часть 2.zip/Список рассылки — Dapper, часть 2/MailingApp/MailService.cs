﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;

namespace MailingApp
{
    public class SectionRank
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Count { get; set; }
    }

    public static class MailService
    {
        public static int Age(DateTime birthDate, DateTime today)
        {
            int age = today.Year - birthDate.Year;

            if (birthDate.Date.AddYears(age) > today.Date)
                age--;

            return age;
        }

        public static string GenderName(Gender gender)
        {
            return gender == Gender.Male ? "Мужской" : "Женский";
        }

        // Популярность = число подписчиков раздела.
        public static List<SectionRank> Popularity(
            MailingContext db, bool descending, int take,
            Gender? gender = null)
        {
            var query = db.Sections.Select(s => new SectionRank
            {
                Id = s.Id,
                Name = s.Name,
                Count = s.Subscriptions.Count(x =>
                    !gender.HasValue || x.Buyer.Gender == gender.Value)
            });

            return descending
                ? query.OrderByDescending(x => x.Count)
                    .ThenBy(x => x.Id).Take(take).ToList()
                : query.OrderBy(x => x.Count)
                    .ThenBy(x => x.Id).Take(take).ToList();
        }

        // Считаем только действующие сегодня акции.
        public static List<SectionRank> ProductRanks(
            MailingContext db, DateTime today,
            bool descending, int take)
        {
            DateTime day = today.Date;

            var query = db.Sections.Select(s => new SectionRank
            {
                Id = s.Id,
                Name = s.Name,
                Count = s.Promotions.Count(p =>
                    p.StartDate <= day && p.EndDate >= day)
            });

            return descending
                ? query.OrderByDescending(x => x.Count)
                    .ThenBy(x => x.Id).Take(take).ToList()
                : query.OrderBy(x => x.Count)
                    .ThenBy(x => x.Id).Take(take).ToList();
        }

        public static List<Promotion> EndingInThreeDays(
            MailingContext db, DateTime today)
        {
            DateTime day = today.Date;
            DateTime target = day.AddDays(3);
            DateTime next = target.AddDays(1);

            return db.Promotions.Where(p =>
                p.StartDate <= day &&
                p.EndDate >= target && p.EndDate < next)
                .OrderBy(p => p.Id).ToList();
        }

        public static List<Promotion> Expired(
            MailingContext db, DateTime today)
        {
            DateTime day = today.Date;

            return db.Promotions.Where(p => p.EndDate < day)
                .OrderBy(p => p.Id).ToList();
        }

        public static int ArchiveExpired(
            MailingContext db, DateTime today)
        {
            // При вызове из теста используем уже открытую транзакцию.
            using (var transaction = db.Database.CurrentTransaction == null
                ? db.Database.BeginTransaction(IsolationLevel.Serializable)
                : null)
            {
                var expired = Expired(db, today);

                foreach (var item in expired)
                {
                    db.Archive.Add(new ArchivedPromotion
                    {
                        OriginalId = item.Id,
                        ProductName = item.ProductName,
                        Price = item.Price,
                        StartDate = item.StartDate,
                        EndDate = item.EndDate,
                        SectionId = item.SectionId,
                        ArchivedAt = today.Date
                    });
                }

                db.Promotions.RemoveRange(expired);
                db.SaveChanges();

                if (transaction != null)
                    transaction.Commit();

                return expired.Count;
            }
        }

        public static void AverageBySection(
            MailingContext db, DateTime today)
        {
            var sections = db.Sections.OrderBy(s => s.Id).ToList();

            var subscriptions = db.Subscriptions
                .Include(s => s.Buyer).ToList();

            foreach (var section in sections)
            {
                var ages = subscriptions
                    .Where(s => s.SectionId == section.Id)
                    .Select(s => Age(s.Buyer.BirthDate, today))
                    .ToList();

                Console.WriteLine(ages.Count == 0
                    ? section.Name + ": нет подписчиков"
                    : $"{section.Name}: {ages.Average():F1} лет");
            }
        }

        public static void AverageByLocation(
            MailingContext db, DateTime today, bool byCountry)
        {
            var buyers = db.Buyers.ToList();

            var groups = buyers.GroupBy(b =>
                byCountry ? b.Country : b.City);

            foreach (var group in groups.OrderBy(g => g.Key))
            {
                double average = group.Average(b =>
                    Age(b.BirthDate, today));

                Console.WriteLine($"{group.Key}: {average:F1} лет");
            }
        }

        public static void GenderCounts(MailingContext db)
        {
            foreach (Gender gender in Enum.GetValues(typeof(Gender)))
            {
                int count = db.Buyers.Count(b => b.Gender == gender);
                Console.WriteLine($"{GenderName(gender)}: {count}");
            }
        }

        public static void GenderCountsByCountry(MailingContext db)
        {
            var buyers = db.Buyers.ToList();

            foreach (var country in buyers.GroupBy(b => b.Country)
                .OrderBy(g => g.Key))
            {
                Console.WriteLine(country.Key);

                foreach (Gender gender in Enum.GetValues(typeof(Gender)))
                {
                    int count = country.Count(b => b.Gender == gender);
                    Console.WriteLine($"  {GenderName(gender)}: {count}");
                }
            }
        }

        public static void Seed(MailingContext db, DateTime today)
        {
            if (db.Sections.Any())
                return;

            DateTime day = today.Date;

            var tech = new Section { Name = "Техника" };
            var books = new Section { Name = "Книги" };
            var sport = new Section { Name = "Спорт" };
            var clothes = new Section { Name = "Одежда" };

            db.Sections.AddRange(new[] { tech, books, sport, clothes });

            var ivan = new Buyer
            {
                Name = "Иван",
                Email = "ivan@example.com",
                Gender = Gender.Male,
                BirthDate = day.AddYears(-30),
                City = "Чита",
                Country = "Россия"
            };

            var anna = new Buyer
            {
                Name = "Анна",
                Email = "anna@example.com",
                Gender = Gender.Female,
                BirthDate = day.AddYears(-20),
                City = "Москва",
                Country = "Россия"
            };

            var olga = new Buyer
            {
                Name = "Ольга",
                Email = "olga@example.com",
                Gender = Gender.Female,
                BirthDate = day.AddYears(-40),
                City = "Чита",
                Country = "Россия"
            };

            var max = new Buyer
            {
                Name = "Макс",
                Email = "max@example.com",
                Gender = Gender.Male,
                BirthDate = day.AddYears(-50),
                City = "Берлин",
                Country = "Германия"
            };

            db.Buyers.AddRange(new[] { ivan, anna, olga, max });

            db.Subscriptions.AddRange(new[]
            {
                new Subscription { Buyer = ivan, Section = tech },
                new Subscription { Buyer = ivan, Section = books },
                new Subscription { Buyer = anna, Section = tech },
                new Subscription { Buyer = olga, Section = books },
                new Subscription { Buyer = olga, Section = sport },
                new Subscription { Buyer = max, Section = tech }
            });

            db.Promotions.AddRange(new[]
            {
                new Promotion
                {
                    ProductName = "Ноутбук", Price = 50000,
                    Section = tech,
                    StartDate = day.AddDays(-5),
                    EndDate = day.AddDays(3)
                },
                new Promotion
                {
                    ProductName = "Мышь", Price = 1000,
                    Section = tech,
                    StartDate = day.AddDays(-5),
                    EndDate = day.AddDays(10)
                },
                new Promotion
                {
                    ProductName = "Клавиатура", Price = 2000,
                    Section = tech,
                    StartDate = day.AddDays(-10),
                    EndDate = day.AddDays(-1)
                },
                new Promotion
                {
                    ProductName = "Книга", Price = 500,
                    Section = books,
                    StartDate = day.AddDays(-5),
                    EndDate = day.AddDays(3)
                },
                new Promotion
                {
                    ProductName = "Мяч", Price = 1500,
                    Section = sport,
                    StartDate = day.AddDays(-10),
                    EndDate = day.AddDays(-2)
                }
            });

            db.SaveChanges();
        }
    }
}
