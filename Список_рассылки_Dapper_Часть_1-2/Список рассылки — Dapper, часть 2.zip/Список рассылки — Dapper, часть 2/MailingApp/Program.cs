﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailingApp
{
    internal class Program
    {
        static void ShowRanks(IEnumerable<SectionRank> ranks)
        {
            foreach (var item in ranks)
                Console.WriteLine($"{item.Name}: {item.Count}");
        }

        static void ShowPromotions(IEnumerable<Promotion> promotions)
        {
            var list = promotions.ToList();

            if (list.Count == 0)
                Console.WriteLine("Акции не найдены.");

            foreach (var item in list)
            {
                Console.WriteLine(
                    $"{item.ProductName} | Цена: {item.Price} | " +
                    $"{item.StartDate:dd.MM.yyyy} — " +
                    $"{item.EndDate:dd.MM.yyyy}");
            }
        }

        static void GenderRanks(MailingContext db, int take)
        {
            foreach (Gender gender in Enum.GetValues(typeof(Gender)))
            {
                Console.WriteLine(MailService.GenderName(gender));

                ShowRanks(MailService.Popularity(
                    db, true, take, gender));
            }
        }

        static async Task Main()
        {
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            // заполняем базу, если начальных данных еще нет
            try
            {
                using (var db = new MailingContext())
                    MailService.Seed(db, DateTime.Today);
            }
            catch (Exception ex)
            {
                Console.WriteLine(
                    "Ошибка подключения: " +
                    ex.GetBaseException().Message);

                Console.WriteLine(
                    "Проверь App.config и выполни Update-Database.");

                Console.ReadLine();
                return;
            }

            while (true)
            {
                Console.WriteLine(
                    "\n1. Тесты работы с БД" +
                    "\n2. Топ-3 популярных разделов" +
                    "\n3. Самый популярный раздел" +
                    "\n4. Топ-3 непопулярных разделов" +
                    "\n5. Самый непопулярный раздел" +
                    "\n6. Топ-3 разделов по числу акционных товаров" +
                    "\n7. Больше всего акционных товаров" +
                    "\n8. Топ-3 разделов с наименьшим числом товаров" +
                    "\n9. Меньше всего акционных товаров" +
                    "\n10. До конца акции осталось три дня" +
                    "\n11. Просроченные акции" +
                    "\n12. Перенести просроченные акции в архив" +
                    "\n13. Средний возраст по разделам" +
                    "\n14. Средний возраст по городам" +
                    "\n15. Средний возраст по странам" +
                    "\n16. Самый популярный раздел для каждого пола" +
                    "\n17. Топ-3 разделов для каждого пола" +
                    "\n18. Количество покупателей каждого пола" +
                    "\n19. Количество покупателей каждого пола по странам" +
                    "\n20. Просмотр архива" +
                    "\n21. Количество покупателей в каждом городе" +
                    "\n22. Количество покупателей в каждой стране" +
                    "\n23. Количество городов в каждой стране" +
                    "\n24. Среднее количество городов по странам" +
                    "\n25. Интересы покупателей указанной страны" +
                    "\n26. Акции раздела за период" +
                    "\n27. Действующие акции для покупателя" +
                    "\n28. Топ-3 стран по количеству покупателей" +
                    "\n29. Лучшая страна по количеству покупателей" +
                    "\n30. Топ-3 городов по количеству покупателей" +
                    "\n31. Лучший город по количеству покупателей" +
                    "\n32. Список покупателей и разделов с ID" +
                    "\n0. Выход");

                Console.Write("Выбор: ");
                string choice = Console.ReadLine();

                if (choice == null || choice == "0")
                    return;

                DateTime today = DateTime.Today;

                try
                {
                    // новые запросы выполняются асинхронно через dapper
                    if (int.TryParse(choice, out int punkt) &&
                        punkt >= 21 && punkt <= 32)
                    {
                        await DapperZaprosy.Vypolnit(choice);
                        continue;
                    }

                    if (choice == "1")
                    {
                        DbTests.Run();
                        continue;
                    }

                    // прежние пункты работают через entity framework
                    using (var db = new MailingContext())
                    {
                        switch (choice)
                        {
                            case "2":
                                ShowRanks(MailService.Popularity(
                                    db, true, 3));
                                break;

                            case "3":
                                ShowRanks(MailService.Popularity(
                                    db, true, 1));
                                break;

                            case "4":
                                ShowRanks(MailService.Popularity(
                                    db, false, 3));
                                break;

                            case "5":
                                ShowRanks(MailService.Popularity(
                                    db, false, 1));
                                break;

                            case "6":
                                ShowRanks(MailService.ProductRanks(
                                    db, today, true, 3));
                                break;

                            case "7":
                                ShowRanks(MailService.ProductRanks(
                                    db, today, true, 1));
                                break;

                            case "8":
                                ShowRanks(MailService.ProductRanks(
                                    db, today, false, 3));
                                break;

                            case "9":
                                ShowRanks(MailService.ProductRanks(
                                    db, today, false, 1));
                                break;

                            case "10":
                                ShowPromotions(
                                    MailService.EndingInThreeDays(db, today));
                                break;

                            case "11":
                                ShowPromotions(
                                    MailService.Expired(db, today));
                                break;

                            case "12":
                                int count = MailService.ArchiveExpired(
                                    db, today);

                                Console.WriteLine(
                                    $"Перенесено в архив: {count}");
                                break;

                            case "13":
                                MailService.AverageBySection(db, today);
                                break;

                            case "14":
                                MailService.AverageByLocation(
                                    db, today, false);
                                break;

                            case "15":
                                MailService.AverageByLocation(
                                    db, today, true);
                                break;

                            case "16":
                                GenderRanks(db, 1);
                                break;

                            case "17":
                                GenderRanks(db, 3);
                                break;

                            case "18":
                                MailService.GenderCounts(db);
                                break;

                            case "19":
                                MailService.GenderCountsByCountry(db);
                                break;

                            case "20":
                                var archive = db.Archive
                                    .OrderBy(a => a.Id)
                                    .ToList();

                                if (archive.Count == 0)
                                    Console.WriteLine("Архив пуст.");

                                foreach (var item in archive)
                                {
                                    Console.WriteLine(
                                        $"{item.ProductName} | " +
                                        $"Цена: {item.Price} | " +
                                        $"Конец акции: {item.EndDate:dd.MM.yyyy} | " +
                                        $"В архиве с: {item.ArchivedAt:dd.MM.yyyy}");
                                }
                                break;

                            default:
                                Console.WriteLine("Нет такого пункта.");
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(
                        "Ошибка: " + ex.GetBaseException().Message);
                }
            }
        }
    }
}