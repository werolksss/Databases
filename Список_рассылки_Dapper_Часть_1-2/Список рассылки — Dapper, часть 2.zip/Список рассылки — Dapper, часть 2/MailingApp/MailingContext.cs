﻿using System.Data.Entity;

namespace MailingApp
{
    public class MailingContext : DbContext
    {
        static MailingContext()
        {
            Database.SetInitializer<MailingContext>(null);
        }

        public MailingContext() : base("name=MailingDb")
        {
        }

        public MailingContext(string connectionName)
            : base("name=" + connectionName)
        {
        }

        public DbSet<Buyer> Buyers { get; set; }
        public DbSet<Section> Sections { get; set; }
        public DbSet<Subscription> Subscriptions { get; set; }
        public DbSet<Promotion> Promotions { get; set; }
        public DbSet<ArchivedPromotion> Archive { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Subscription>()
                .HasKey(s => new { s.BuyerId, s.SectionId });

            modelBuilder.Entity<Subscription>()
                .HasRequired(s => s.Buyer)
                .WithMany()
                .HasForeignKey(s => s.BuyerId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Subscription>()
                .HasRequired(s => s.Section)
                .WithMany(s => s.Subscriptions)
                .HasForeignKey(s => s.SectionId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Promotion>()
                .HasRequired(p => p.Section)
                .WithMany(s => s.Promotions)
                .HasForeignKey(p => p.SectionId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ArchivedPromotion>()
                .ToTable("Архив акций");

            modelBuilder.Entity<ArchivedPromotion>()
                .HasRequired(p => p.Section)
                .WithMany()
                .HasForeignKey(p => p.SectionId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Promotion>()
                .Property(p => p.Price).HasPrecision(18, 2);

            modelBuilder.Entity<ArchivedPromotion>()
                .Property(p => p.Price).HasPrecision(18, 2);

            base.OnModelCreating(modelBuilder);
        }
    }
}