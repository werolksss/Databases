﻿namespace MailingApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Архив акций",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        OriginalId = c.Int(nullable: false),
                        ProductName = c.String(),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        StartDate = c.DateTime(nullable: false),
                        EndDate = c.DateTime(nullable: false),
                        ArchivedAt = c.DateTime(nullable: false),
                        SectionId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Sections", t => t.SectionId)
                .Index(t => t.SectionId);
            
            CreateTable(
                "dbo.Sections",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Promotions",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ProductName = c.String(),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        StartDate = c.DateTime(nullable: false),
                        EndDate = c.DateTime(nullable: false),
                        SectionId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Sections", t => t.SectionId)
                .Index(t => t.SectionId);
            
            CreateTable(
                "dbo.Subscriptions",
                c => new
                    {
                        BuyerId = c.Int(nullable: false),
                        SectionId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.BuyerId, t.SectionId })
                .ForeignKey("dbo.Buyers", t => t.BuyerId)
                .ForeignKey("dbo.Sections", t => t.SectionId)
                .Index(t => t.BuyerId)
                .Index(t => t.SectionId);
            
            CreateTable(
                "dbo.Buyers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Email = c.String(),
                        Gender = c.Int(nullable: false),
                        BirthDate = c.DateTime(nullable: false),
                        City = c.String(),
                        Country = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Архив акций", "SectionId", "dbo.Sections");
            DropForeignKey("dbo.Subscriptions", "SectionId", "dbo.Sections");
            DropForeignKey("dbo.Subscriptions", "BuyerId", "dbo.Buyers");
            DropForeignKey("dbo.Promotions", "SectionId", "dbo.Sections");
            DropIndex("dbo.Subscriptions", new[] { "SectionId" });
            DropIndex("dbo.Subscriptions", new[] { "BuyerId" });
            DropIndex("dbo.Promotions", new[] { "SectionId" });
            DropIndex("dbo.Архив акций", new[] { "SectionId" });
            DropTable("dbo.Buyers");
            DropTable("dbo.Subscriptions");
            DropTable("dbo.Promotions");
            DropTable("dbo.Sections");
            DropTable("dbo.Архив акций");
        }
    }
}
