﻿using System;
using System.Linq;

namespace MailingApp
{
    public static class DbTests
    {
        static void Check(bool condition, string name)
        {
            if (!condition)
                throw new Exception("Тест не пройден: " + name);

            Console.WriteLine("OK: " + name);
        }

        public static void Run()
        {
            DateTime today = DateTime.Today;

            using (var db = new MailingContext("MailingTestsDb"))
            {
                // Создаётся только отдельная тестовая база.
                db.Database.CreateIfNotExists();

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        if (db.Sections.Any() || db.Buyers.Any()
                            || db.Promotions.Any() || db.Archive.Any())
                        {
                            throw new Exception(
                                "Тестовая база должна быть пустой. " +
                                "Не используй MailingTestsDb для обычной работы.");
                        }

                        MailService.Seed(db, today);

                        Check(db.Buyers.Count() == 4,
                            "Добавление и чтение покупателей");

                        var buyer = db.Buyers.First(b => b.Name == "Иван");
                        buyer.Name = "Иван изменён";
                        db.SaveChanges();

                        db.Entry(buyer).Reload();

                        Check(buyer.Name == "Иван изменён",
                            "Изменение покупателя в БД");

                        var temporary = new Buyer
                        {
                            Name = "Тест",
                            Email = "test@example.com",
                            Gender = Gender.Male,
                            BirthDate = today.AddYears(-25),
                            City = "Тест",
                            Country = "Тест"
                        };

                        db.Buyers.Add(temporary);
                        db.SaveChanges();
                        int temporaryId = temporary.Id;

                        db.Buyers.Remove(temporary);
                        db.SaveChanges();

                        Check(!db.Buyers.Any(b => b.Id == temporaryId),
                            "Удаление покупателя из БД");

                        var popular = MailService.Popularity(db, true, 3);

                        Check(popular.Count == 3
                            && popular[0].Name == "Техника"
                            && popular[0].Count == 3,
                            "Топ разделов по подписчикам");

                        Check(MailService.Popularity(db, false, 1)[0]
                            .Name == "Одежда",
                            "Раздел без подписчиков участвует в рейтинге");

                        Check(MailService.ProductRanks(db, today, true, 1)[0]
                            .Count == 2,
                            "Подсчёт действующих акционных товаров");

                        Check(MailService.EndingInThreeDays(db, today)
                            .Count == 2,
                            "Акции, заканчивающиеся через три дня");

                        Check(MailService.Expired(db, today).Count == 2,
                            "Поиск просроченных акций");

                        var man = MailService.Popularity(
                            db, true, 1, Gender.Male)[0];

                        Check(man.Name == "Техника" && man.Count == 2,
                            "Популярность разделов среди мужчин");

                        Check(db.Buyers.Count(b =>
                            b.Gender == Gender.Female) == 2,
                            "Количество покупателей женского пола");

                        double average = db.Buyers.ToList()
                            .Where(b => b.City == "Чита")
                            .Average(b => MailService.Age(b.BirthDate, today));

                        Check(Math.Abs(average - 35) < 0.001,
                            "Средний возраст покупателей города");

                        Check(MailService.Age(
                            today.AddYears(-30).AddDays(1), today) == 29,
                            "Возраст до наступления дня рождения");

                        int moved = MailService.ArchiveExpired(db, today);

                        Check(moved == 2 && db.Archive.Count() == 2
                            && !db.Promotions.Any(p => p.EndDate < today),
                            "Перенос просроченных акций в архив");

                        Check(MailService.ArchiveExpired(db, today) == 0
                            && db.Archive.Count() == 2,
                            "Повторный перенос не создаёт дубликаты");

                        Console.WriteLine("\nВсе проверки пройдены.");
                    }
                    finally
                    {
                        // Все тестовые изменения отменяются.
                        transaction.Rollback();
                    }
                }
            }
        }
    }
}