﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Dapper;

namespace MailingApp
{
    static class DapperChast1
    {
        static string Tekst(string vopros)
        {
            Console.Write(vopros);
            string tekst = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(tekst))
                throw new Exception("Введите непустое значение.");

            return tekst.Trim();
        }

        static async Task Pokupateli(
            SqlConnection baza, string sql, object parametry = null)
        {
            var pokupateli = (await baza.QueryAsync<Buyer>(
                sql, parametry)).ToList();

            if (pokupateli.Count == 0)
                Console.WriteLine("Покупатели не найдены.");

            foreach (var pokupatel in pokupateli)
            {
                string pol = pokupatel.Gender == Gender.Male
                    ? "мужской"
                    : "женский";

                Console.WriteLine(
                    $"{pokupatel.Id}. {pokupatel.Name} | " +
                    $"{pokupatel.BirthDate:dd.MM.yyyy} | {pol} | " +
                    $"{pokupatel.Email} | " +
                    $"{pokupatel.Country}, {pokupatel.City}");
            }
        }

        static async Task Aktsii(
            SqlConnection baza, string sql, object parametry = null)
        {
            var aktsii = (await baza.QueryAsync<Promotion>(
                sql, parametry)).ToList();

            if (aktsii.Count == 0)
                Console.WriteLine("Акции не найдены.");

            foreach (var aktsiya in aktsii)
            {
                Console.WriteLine(
                    $"{aktsiya.Id}. {aktsiya.ProductName} | " +
                    $"{aktsiya.Price:N2} руб. | " +
                    $"Страна: {aktsiya.Country} | " +
                    $"ID раздела: {aktsiya.SectionId} | " +
                    $"{aktsiya.StartDate:dd.MM.yyyy} — " +
                    $"{aktsiya.EndDate:dd.MM.yyyy}");
            }
        }

        static async Task Spisok(SqlConnection baza, string sql)
        {
            var stroki = (await baza.QueryAsync<string>(sql)).ToList();

            if (stroki.Count == 0)
                Console.WriteLine("Данных нет.");

            foreach (var stroka in stroki)
                Console.WriteLine(stroka);
        }

        public static async Task Zapustit()
        {
            var nastroyka =
                ConfigurationManager.ConnectionStrings["MailingDb"];

            if (nastroyka == null)
                throw new Exception("В App.config нет подключения MailingDb.");

            // соединение освобождается при выходе из меню
            using (var baza = new SqlConnection(nastroyka.ConnectionString))
            {
                while (true)
                {
                    Console.WriteLine("\nСПИСОК РАССЫЛКИ — DAPPER, ЧАСТЬ 1");

                    Console.WriteLine(
                        "Подключение: " +
                        (baza.State == ConnectionState.Open
                            ? "открыто"
                            : "закрыто"));

                    Console.WriteLine("1 — подключиться");
                    Console.WriteLine("2 — отключиться");
                    Console.WriteLine("3 — все покупатели");
                    Console.WriteLine("4 — email всех покупателей");
                    Console.WriteLine("5 — список разделов");
                    Console.WriteLine("6 — список акционных товаров");
                    Console.WriteLine("7 — все города");
                    Console.WriteLine("8 — все страны");
                    Console.WriteLine("9 — покупатели из города");
                    Console.WriteLine("10 — покупатели из страны");
                    Console.WriteLine("11 — акции для страны");
                    Console.WriteLine("0 — вернуться в главное меню");
                    Console.Write("Выбор: ");

                    string vybor = Console.ReadLine();

                    if (vybor == null || vybor == "0")
                        return;

                    try
                    {
                        if (vybor == "1")
                        {
                            if (baza.State == ConnectionState.Open)
                            {
                                Console.WriteLine("Подключение уже открыто.");
                            }
                            else
                            {
                                baza.Close();
                                await baza.OpenAsync();
                                Console.WriteLine("Подключение успешно.");
                            }

                            continue;
                        }

                        if (vybor == "2")
                        {
                            baza.Close();
                            Console.WriteLine("Подключение закрыто.");
                            continue;
                        }

                        // сначала нужно открыть соединение
                        if (baza.State != ConnectionState.Open)
                        {
                            Console.WriteLine(
                                "Сначала выберите 1 — подключиться.");
                            continue;
                        }

                        switch (vybor)
                        {
                            case "3":
                                await Pokupateli(
                                    baza,
                                    @"SELECT Id, Name, Email, Gender,
                                             BirthDate, City, Country
                                      FROM Buyers ORDER BY Id");
                                break;

                            case "4":
                                await Spisok(
                                    baza,
                                    "SELECT Email FROM Buyers ORDER BY Id");
                                break;

                            case "5":
                                var razdely = (await baza.QueryAsync<Section>(
                                    "SELECT Id, Name FROM Sections ORDER BY Id"))
                                    .ToList();

                                if (razdely.Count == 0)
                                    Console.WriteLine("Разделов нет.");

                                foreach (var razdel in razdely)
                                    Console.WriteLine(
                                        $"{razdel.Id}. {razdel.Name}");
                                break;

                            case "6":
                                await Aktsii(
                                    baza,
                                    @"SELECT Id, ProductName, Country,
                                             Price, StartDate, EndDate, SectionId
                                      FROM Promotions ORDER BY Id");
                                break;

                            case "7":
                                await Spisok(
                                    baza,
                                    @"SELECT DISTINCT City
                                      FROM Buyers ORDER BY City");
                                break;

                            case "8":
                                await Spisok(
                                    baza,
                                    @"SELECT DISTINCT Country
                                      FROM Buyers ORDER BY Country");
                                break;

                            case "9":
                                string gorod = Tekst("Город: ");

                                await Pokupateli(
                                    baza,
                                    @"SELECT Id, Name, Email, Gender,
                                             BirthDate, City, Country
                                      FROM Buyers
                                      WHERE City = @gorod
                                      ORDER BY Id",
                                    new { gorod });
                                break;

                            case "10":
                                string strana = Tekst("Страна: ");

                                await Pokupateli(
                                    baza,
                                    @"SELECT Id, Name, Email, Gender,
                                             BirthDate, City, Country
                                      FROM Buyers
                                      WHERE Country = @strana
                                      ORDER BY Id",
                                    new { strana });
                                break;

                            case "11":
                                string stranaAktsii = Tekst("Страна акции: ");

                                await Aktsii(
                                    baza,
                                    @"SELECT Id, ProductName, Country,
                                             Price, StartDate, EndDate, SectionId
                                      FROM Promotions
                                      WHERE Country = @stranaAktsii
                                      ORDER BY Id",
                                    new { stranaAktsii });
                                break;

                            default:
                                Console.WriteLine("Нет такого пункта.");
                                break;
                        }
                    }
                    catch (Exception oshibka)
                    {
                        Console.WriteLine(
                            "Ошибка: " + oshibka.GetBaseException().Message);
                    }
                }
            }
        }
    }
}