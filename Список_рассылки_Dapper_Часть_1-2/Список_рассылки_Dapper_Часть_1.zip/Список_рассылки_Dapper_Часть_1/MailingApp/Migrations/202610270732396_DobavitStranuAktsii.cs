﻿using System.Data.Entity.Migrations;

namespace MailingApp.Migrations
{
    public partial class DobavitStranuAktsii : DbMigration
    {
        public override void Up()
        {
            // добавляем страну акции и архиву
            AddColumn(
                "dbo.Promotions",
                "Country",
                c => c.String());

            AddColumn(
                "dbo.Архив акций",
                "Country",
                c => c.String());

            // заполняем страну существующим записям
            Sql(
                "UPDATE dbo.Promotions " +
                "SET Country = N'Россия' WHERE Country IS NULL");

            Sql(
                "UPDATE dbo.[Архив акций] " +
                "SET Country = N'Россия' WHERE Country IS NULL");
        }

        public override void Down()
        {
            DropColumn("dbo.Архив акций", "Country");
            DropColumn("dbo.Promotions", "Country");
        }
    }
}