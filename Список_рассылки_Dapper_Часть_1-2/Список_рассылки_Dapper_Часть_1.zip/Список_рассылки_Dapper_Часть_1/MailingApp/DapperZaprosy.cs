﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Dapper;

namespace MailingApp
{
    public class Itog
    {
        public string Nazvanie { get; set; }
        public string Strana { get; set; }
        public int Kolichestvo { get; set; }
    }

    public class Interes
    {
        public string Imya { get; set; }
        public string Razdel { get; set; }
    }

    static class DapperZaprosy
    {
        static string Tekst(string vopros)
        {
            Console.Write(vopros);
            string tekst = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(tekst))
                throw new Exception("Введите непустое значение.");

            return tekst.Trim();
        }

        static int Chislo(string vopros)
        {
            if (!int.TryParse(Tekst(vopros), out int chislo) || chislo <= 0)
                throw new Exception("Введите положительный ID.");

            return chislo;
        }

        static DateTime Data(string vopros)
        {
            if (!DateTime.TryParseExact(
                Tekst(vopros),
                "dd.MM.yyyy",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out DateTime data))
            {
                throw new Exception("Формат даты: дд.мм.гггг.");
            }

            return data.Date;
        }

        static async Task PokazatItogi(
            SqlConnection baza, string sql, object parametry = null)
        {
            var stroki = (await baza.QueryAsync<Itog>(
                sql, parametry)).ToList();

            if (stroki.Count == 0)
                Console.WriteLine("Данных нет.");

            foreach (var stroka in stroki)
            {
                string mesto = string.IsNullOrEmpty(stroka.Strana)
                    ? stroka.Nazvanie
                    : $"{stroka.Nazvanie}, {stroka.Strana}";

                Console.WriteLine($"{mesto}: {stroka.Kolichestvo}");
            }
        }

        static async Task PokazatAktsii(
            SqlConnection baza, string sql, object parametry)
        {
            var aktsii = (await baza.QueryAsync<Promotion>(
                sql, parametry)).ToList();

            if (aktsii.Count == 0)
                Console.WriteLine("Акции не найдены.");

            foreach (var aktsiya in aktsii)
            {
                Console.WriteLine(
                    $"{aktsiya.ProductName} | {aktsiya.Price:N2} руб. | " +
                    $"{aktsiya.Country} | " +
                    $"{aktsiya.StartDate:dd.MM.yyyy} — " +
                    $"{aktsiya.EndDate:dd.MM.yyyy}");
            }
        }

        static async Task Interesy(SqlConnection baza)
        {
            string strana = Tekst("Страна: ");
            string tekst = Tekst("ID покупателей через запятую: ");

            // превращаем введенные id в массив
            string[] chasti = tekst.Split(',');
            int[] nomera = new int[chasti.Length];

            for (int i = 0; i < chasti.Length; i++)
            {
                if (!int.TryParse(chasti[i].Trim(), out nomera[i]) ||
                    nomera[i] <= 0)
                {
                    throw new Exception(
                        "Введите положительные ID через запятую.");
                }
            }

            nomera = nomera.Distinct().ToArray();

            int naydeno = await baza.ExecuteScalarAsync<int>(
                @"SELECT COUNT(*)
                  FROM Buyers
                  WHERE Country = @strana AND Id IN @nomera",
                new { strana, nomera });

            if (naydeno != nomera.Length)
                throw new Exception(
                    "Не все покупатели найдены в указанной стране.");

            var interesy = (await baza.QueryAsync<Interes>(
                @"SELECT Buyers.Name AS Imya,
                         Sections.Name AS Razdel
                  FROM Buyers
                  JOIN Subscriptions
                    ON Buyers.Id = Subscriptions.BuyerId
                  JOIN Sections
                    ON Subscriptions.SectionId = Sections.Id
                  WHERE Buyers.Country = @strana
                    AND Buyers.Id IN @nomera
                  ORDER BY Buyers.Name, Sections.Name",
                new { strana, nomera })).ToList();

            if (interesy.Count == 0)
                Console.WriteLine("У покупателей нет подписок.");

            foreach (var interes in interesy)
                Console.WriteLine($"{interes.Imya}: {interes.Razdel}");
        }

        static async Task AktsiiZaPeriod(SqlConnection baza)
        {
            int razdel = Chislo("ID раздела: ");
            DateTime nachalo = Data("Начало периода: ");
            DateTime konets = Data("Конец периода: ");

            if (konets < nachalo)
                throw new Exception("Конец периода раньше начала.");

            if (konets == DateTime.MaxValue.Date)
                throw new Exception("Введите дату раньше 31.12.9999.");

            DateTime posleKontsa = konets.AddDays(1);

            int naydeno = await baza.ExecuteScalarAsync<int>(
                "SELECT COUNT(*) FROM Sections WHERE Id = @razdel",
                new { razdel });

            if (naydeno == 0)
                throw new Exception("Раздел не найден.");

            // акция должна пересекаться с выбранным периодом
            await PokazatAktsii(
                baza,
                @"SELECT Id, ProductName, Country, Price,
                         StartDate, EndDate, SectionId
                  FROM Promotions
                  WHERE SectionId = @razdel
                    AND StartDate < @posleKontsa
                    AND EndDate >= @nachalo
                  ORDER BY StartDate, Id",
                new { razdel, nachalo, posleKontsa });
        }

        static async Task AktsiiPokupatelya(SqlConnection baza)
        {
            int pokupatel = Chislo("ID покупателя: ");
            DateTime segodnya = DateTime.Today;

            int naydeno = await baza.ExecuteScalarAsync<int>(
                "SELECT COUNT(*) FROM Buyers WHERE Id = @pokupatel",
                new { pokupatel });

            if (naydeno == 0)
                throw new Exception("Покупатель не найден.");

            // учитываем подписки, страну и срок акции
            await PokazatAktsii(
                baza,
                @"SELECT Promotions.Id, Promotions.ProductName,
                         Promotions.Country, Promotions.Price,
                         Promotions.StartDate, Promotions.EndDate,
                         Promotions.SectionId
                  FROM Promotions
                  JOIN Subscriptions
                    ON Promotions.SectionId = Subscriptions.SectionId
                  WHERE Subscriptions.BuyerId = @pokupatel
                    AND Promotions.Country =
                        (SELECT Country FROM Buyers WHERE Id = @pokupatel)
                    AND Promotions.StartDate <= @segodnya
                    AND Promotions.EndDate >= @segodnya
                  ORDER BY Promotions.Id",
                new { pokupatel, segodnya });
        }

        static async Task Spravochnik(SqlConnection baza)
        {
            Console.WriteLine("ПОКУПАТЕЛИ:");

            var pokupateli = await baza.QueryAsync<Buyer>(
                @"SELECT Id, Name, Country, City
                  FROM Buyers ORDER BY Id");

            foreach (var pokupatel in pokupateli)
            {
                Console.WriteLine(
                    $"{pokupatel.Id}. {pokupatel.Name} | " +
                    $"{pokupatel.Country}, {pokupatel.City}");
            }

            Console.WriteLine("\nРАЗДЕЛЫ:");

            var razdely = await baza.QueryAsync<Section>(
                "SELECT Id, Name FROM Sections ORDER BY Id");

            foreach (var razdel in razdely)
                Console.WriteLine($"{razdel.Id}. {razdel.Name}");
        }

        public static async Task Vypolnit(string vybor)
        {
            var nastroyka =
                ConfigurationManager.ConnectionStrings["MailingDb"];

            if (nastroyka == null)
                throw new Exception("Нет подключения MailingDb в App.config.");

            using (var baza = new SqlConnection(nastroyka.ConnectionString))
            {
                await baza.OpenAsync();

                switch (vybor)
                {
                    case "21":
                        await PokazatItogi(
                            baza,
                            @"SELECT City AS Nazvanie, Country AS Strana,
                                     COUNT(*) AS Kolichestvo
                              FROM Buyers
                              GROUP BY Country, City
                              ORDER BY Country, City");
                        break;

                    case "22":
                        await PokazatItogi(
                            baza,
                            @"SELECT Country AS Nazvanie,
                                     COUNT(*) AS Kolichestvo
                              FROM Buyers
                              GROUP BY Country
                              ORDER BY Country");
                        break;

                    case "23":
                        await PokazatItogi(
                            baza,
                            @"SELECT Country AS Nazvanie,
                                     COUNT(DISTINCT City) AS Kolichestvo
                              FROM Buyers
                              GROUP BY Country
                              ORDER BY Country");
                        break;

                    case "24":
                        // считаем среднее по количеству городов в странах
                        decimal srednee =
                            await baza.ExecuteScalarAsync<decimal>(
                                @"SELECT COALESCE(
                                      AVG(CAST(Kolichestvo AS decimal(18, 2))),
                                      0)
                                  FROM
                                  (
                                      SELECT COUNT(DISTINCT City) AS Kolichestvo
                                      FROM Buyers
                                      GROUP BY Country
                                  ) AS Goroda");

                        Console.WriteLine(
                            $"Среднее количество городов: {srednee:F2}");
                        break;

                    case "25":
                        await Interesy(baza);
                        break;

                    case "26":
                        await AktsiiZaPeriod(baza);
                        break;

                    case "27":
                        await AktsiiPokupatelya(baza);
                        break;

                    case "28":
                    case "29":
                        await PokazatItogi(
                            baza,
                            @"SELECT TOP (@skolko)
                                     Country AS Nazvanie,
                                     COUNT(*) AS Kolichestvo
                              FROM Buyers
                              GROUP BY Country
                              ORDER BY COUNT(*) DESC, Country",
                            new { skolko = vybor == "28" ? 3 : 1 });
                        break;

                    case "30":
                    case "31":
                        await PokazatItogi(
                            baza,
                            @"SELECT TOP (@skolko)
                                     City AS Nazvanie,
                                     Country AS Strana,
                                     COUNT(*) AS Kolichestvo
                              FROM Buyers
                              GROUP BY Country, City
                              ORDER BY COUNT(*) DESC, Country, City",
                            new { skolko = vybor == "30" ? 3 : 1 });
                        break;

                    case "32":
                        await Spravochnik(baza);
                        break;
                }
            }
        }
    }
}