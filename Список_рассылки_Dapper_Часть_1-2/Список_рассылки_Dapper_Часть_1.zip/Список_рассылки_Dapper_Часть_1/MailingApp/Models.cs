﻿using System;
using System.Collections.Generic;

namespace MailingApp
{
    public enum Gender
    {
        Male,
        Female
    }

    public class Buyer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public Gender Gender { get; set; }
        public DateTime BirthDate { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
    }

    public class Section
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Subscription> Subscriptions { get; set; }
            = new List<Subscription>();

        public virtual ICollection<Promotion> Promotions { get; set; }
            = new List<Promotion>();
    }

    public class Subscription
    {
        public int BuyerId { get; set; }
        public int SectionId { get; set; }

        public virtual Buyer Buyer { get; set; }
        public virtual Section Section { get; set; }
    }

    public class Promotion
    {
        public int Id { get; set; }
        public string ProductName { get; set; }

        // акция привязана к стране
        public string Country { get; set; } = "Россия";

        public decimal Price { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public int SectionId { get; set; }
        public virtual Section Section { get; set; }
    }

    public class ArchivedPromotion
    {
        public int Id { get; set; }
        public int OriginalId { get; set; }
        public string ProductName { get; set; }

        // сохраняем страну и в архиве
        public string Country { get; set; } = "Россия";

        public decimal Price { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime ArchivedAt { get; set; }

        public int SectionId { get; set; }
        public virtual Section Section { get; set; }
    }
}