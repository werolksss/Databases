﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace FootballCoreApp;

public static class LeagueService
{
    public static void Seed(LeagueContext db)
    {
        if (db.Teams.Any())
            return;

        var teams = new[]
        {
            new Team { Name = "Real Madrid", City = "Madrid" },
            new Team { Name = "Barcelona", City = "Barcelona" },
            new Team { Name = "Atletico Madrid", City = "Madrid" },
            new Team { Name = "Sevilla", City = "Sevilla" }
        };

        db.Teams.AddRange(teams);
        db.SaveChanges();

        foreach (var team in teams)
        {
            for (int i = 1; i <= 3; i++)
            {
                db.Players.Add(new Player
                {
                    TeamId = team.Id,
                    FullName = $"{team.Name}: Игрок {i}"
                });
            }
        }

        db.SaveChanges();
    }

    public static void Generate(LeagueContext db, DateTime start)
    {
        db.Database.ExecuteSqlInterpolated(
            $"EXEC dbo.FillRandomMatches @StartDate={start.Date}");
    }

    public static List<ScorerRow> BestScorers(
        LeagueContext db, int take, int? teamId = null)
    {
        var query = db.Scorers.Where(p => p.Goals > 0);

        if (teamId.HasValue)
            query = query.Where(p => p.TeamId == teamId.Value);

        return query
            .OrderByDescending(p => p.Goals)
            .ThenBy(p => p.PlayerId)
            .Take(take).ToList();
    }

    public static List<TeamRow> MostGoals(
        LeagueContext db, int take)
    {
        return db.Standings
            .OrderByDescending(t => t.GoalsScored)
            .ThenBy(t => t.TeamId)
            .Take(take).ToList();
    }

    public static List<TeamRow> FewestConceded(
        LeagueContext db, int take)
    {
        return db.Standings
            .OrderBy(t => t.GoalsConceded)
            .ThenBy(t => t.TeamId)
            .Take(take).ToList();
    }

    public static List<TeamRow> Points(
        LeagueContext db, int take, bool descending)
    {
        return descending
            ? db.Standings.OrderByDescending(t => t.Points)
                .ThenBy(t => t.TeamId).Take(take).ToList()
            : db.Standings.OrderBy(t => t.Points)
                .ThenBy(t => t.TeamId).Take(take).ToList();
    }
}