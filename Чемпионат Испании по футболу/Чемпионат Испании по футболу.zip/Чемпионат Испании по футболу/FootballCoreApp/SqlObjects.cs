﻿using Microsoft.EntityFrameworkCore;

namespace FootballCoreApp;

public static class SqlObjects
{
    public static void Create(LeagueContext db)
    {
        // Представление: количество голов каждого игрока.
        db.Database.ExecuteSqlRaw("""
            CREATE OR ALTER VIEW dbo.ScorerStats
            AS
            SELECT
                p.Id AS PlayerId,
                p.TeamId,
                p.FullName AS PlayerName,
                t.Name AS TeamName,
                COUNT(g.Id) AS Goals
            FROM dbo.Players p
            JOIN dbo.Teams t ON t.Id = p.TeamId
            LEFT JOIN dbo.Goals g ON g.PlayerId = p.Id
            GROUP BY p.Id, p.TeamId, p.FullName, t.Name;
            """);

        // Представление: статистика команд из результатов матчей.
        db.Database.ExecuteSqlRaw("""
            CREATE OR ALTER VIEW dbo.TeamStats
            AS
            WITH Results AS
            (
                SELECT
                    HomeTeamId AS TeamId,
                    CASE WHEN HomeGoals > AwayGoals THEN 1 ELSE 0 END AS Wins,
                    CASE WHEN HomeGoals < AwayGoals THEN 1 ELSE 0 END AS Losses,
                    CASE WHEN HomeGoals = AwayGoals THEN 1 ELSE 0 END AS Draws,
                    HomeGoals AS GoalsScored,
                    AwayGoals AS GoalsConceded
                FROM dbo.Matches

                UNION ALL

                SELECT
                    AwayTeamId,
                    CASE WHEN AwayGoals > HomeGoals THEN 1 ELSE 0 END,
                    CASE WHEN AwayGoals < HomeGoals THEN 1 ELSE 0 END,
                    CASE WHEN AwayGoals = HomeGoals THEN 1 ELSE 0 END,
                    AwayGoals,
                    HomeGoals
                FROM dbo.Matches
            )
            SELECT
                t.Id AS TeamId,
                t.Name AS TeamName,
                t.City,
                COALESCE(SUM(r.Wins), 0) AS Wins,
                COALESCE(SUM(r.Losses), 0) AS Losses,
                COALESCE(SUM(r.Draws), 0) AS Draws,
                COALESCE(SUM(r.GoalsScored), 0) AS GoalsScored,
                COALESCE(SUM(r.GoalsConceded), 0) AS GoalsConceded,
                COALESCE(SUM(r.Wins * 3 + r.Draws), 0) AS Points
            FROM dbo.Teams t
            LEFT JOIN Results r ON r.TeamId = t.Id
            GROUP BY t.Id, t.Name, t.City;
            """);

        // Хранимая процедура случайного заполнения матчей.
        db.Database.ExecuteSqlRaw("""
            CREATE OR ALTER PROCEDURE dbo.FillRandomMatches
                @StartDate date
            AS
            BEGIN
                SET NOCOUNT ON;
                SET XACT_ABORT ON;

                IF @StartDate IS NULL
                    THROW 50001, N'Не указана дата начала.', 1;

                IF (SELECT COUNT(*) FROM dbo.Teams) < 2
                    THROW 50002, N'Нужно минимум две команды.', 1;

                IF EXISTS
                (
                    SELECT 1
                    FROM dbo.Teams t
                    WHERE NOT EXISTS
                    (
                        SELECT 1
                        FROM dbo.Players p
                        WHERE p.TeamId = t.Id
                    )
                )
                    THROW 50003, N'У каждой команды должен быть игрок.', 1;

                DECLARE @Home int, @Away int;
                DECLARE @HomeGoals int, @AwayGoals int;
                DECLARE @MatchId int, @PlayerId int;
                DECLARE @Counter int, @Day int = 0;

                DECLARE fixtures CURSOR LOCAL FAST_FORWARD FOR
                SELECT a.Id, b.Id
                FROM dbo.Teams a
                JOIN dbo.Teams b ON a.Id < b.Id
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM dbo.Matches m
                    WHERE
                        (m.HomeTeamId = a.Id AND m.AwayTeamId = b.Id)
                        OR
                        (m.HomeTeamId = b.Id AND m.AwayTeamId = a.Id)
                )
                ORDER BY a.Id, b.Id;

                BEGIN TRY
                    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
                    BEGIN TRANSACTION;

                    OPEN fixtures;
                    FETCH NEXT FROM fixtures INTO @Home, @Away;

                    WHILE @@FETCH_STATUS = 0
                    BEGIN
                        SET @HomeGoals = ABS(CHECKSUM(NEWID()) % 6);
                        SET @AwayGoals = ABS(CHECKSUM(NEWID()) % 6);

                        INSERT INTO dbo.Matches
                        (
                            HomeTeamId, AwayTeamId,
                            MatchDate, HomeGoals, AwayGoals
                        )
                        VALUES
                        (
                            @Home, @Away,
                            DATEADD(day, @Day, @StartDate),
                            @HomeGoals, @AwayGoals
                        );

                        SET @MatchId = CONVERT(int, SCOPE_IDENTITY());

                        SET @Counter = 0;

                        WHILE @Counter < @HomeGoals
                        BEGIN
                            SELECT TOP (1) @PlayerId = Id
                            FROM dbo.Players
                            WHERE TeamId = @Home
                            ORDER BY NEWID();

                            INSERT INTO dbo.Goals (MatchId, PlayerId)
                            VALUES (@MatchId, @PlayerId);

                            SET @Counter = @Counter + 1;
                        END;

                        SET @Counter = 0;

                        WHILE @Counter < @AwayGoals
                        BEGIN
                            SELECT TOP (1) @PlayerId = Id
                            FROM dbo.Players
                            WHERE TeamId = @Away
                            ORDER BY NEWID();

                            INSERT INTO dbo.Goals (MatchId, PlayerId)
                            VALUES (@MatchId, @PlayerId);

                            SET @Counter = @Counter + 1;
                        END;

                        SET @Day = @Day + 1;
                        FETCH NEXT FROM fixtures INTO @Home, @Away;
                    END;

                    CLOSE fixtures;
                    DEALLOCATE fixtures;

                    COMMIT TRANSACTION;
                END TRY
                BEGIN CATCH
                    IF XACT_STATE() <> 0
                        ROLLBACK TRANSACTION;

                    THROW;
                END CATCH;
            END;
            """);
    }
}