﻿using System;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace FootballCoreApp;

public static class DbTests
{
    public static (bool Success, string Text) Run()
    {
        var log = new StringBuilder();

        void Check(bool condition, string name)
        {
            if (!condition)
                throw new Exception("Не пройден: " + name);

            log.AppendLine("OK: " + name);
        }

        string database =
            "FootballCoreTest_" + Guid.NewGuid().ToString("N");

        using var db = new LeagueContext(database);
        bool created = false;

        try
        {
            created = db.Database.EnsureCreated();
            SqlObjects.Create(db);

            var a = new Team { Name = "A", City = "Город A" };
            var b = new Team { Name = "B", City = "Город B" };
            var c = new Team { Name = "C", City = "Город C" };
            var d = new Team { Name = "D", City = "Город D" };

            db.Teams.AddRange(a, b, c, d);
            db.SaveChanges();

            var a1 = new Player { TeamId = a.Id, FullName = "A1" };
            var a2 = new Player { TeamId = a.Id, FullName = "A2" };
            var a3 = new Player { TeamId = a.Id, FullName = "A3" };
            var b1 = new Player { TeamId = b.Id, FullName = "B1" };
            var c1 = new Player { TeamId = c.Id, FullName = "C1" };
            var c2 = new Player { TeamId = c.Id, FullName = "C2" };
            var d1 = new Player { TeamId = d.Id, FullName = "D1" };

            db.Players.AddRange(a1, a2, a3, b1, c1, c2, d1);
            db.SaveChanges();

            var ab = new Match
            {
                HomeTeamId = a.Id,
                AwayTeamId = b.Id,
                MatchDate = DateTime.Today,
                HomeGoals = 4,
                AwayGoals = 1
            };

            var ac = new Match
            {
                HomeTeamId = a.Id,
                AwayTeamId = c.Id,
                MatchDate = DateTime.Today,
                HomeGoals = 0,
                AwayGoals = 0
            };

            var bc = new Match
            {
                HomeTeamId = b.Id,
                AwayTeamId = c.Id,
                MatchDate = DateTime.Today,
                HomeGoals = 0,
                AwayGoals = 3
            };

            db.Matches.AddRange(ab, ac, bc);
            db.SaveChanges();

            db.Goals.AddRange(
                new Goal { MatchId = ab.Id, PlayerId = a1.Id },
                new Goal { MatchId = ab.Id, PlayerId = a1.Id },
                new Goal { MatchId = ab.Id, PlayerId = a2.Id },
                new Goal { MatchId = ab.Id, PlayerId = a3.Id },
                new Goal { MatchId = ab.Id, PlayerId = b1.Id },
                new Goal { MatchId = bc.Id, PlayerId = c1.Id },
                new Goal { MatchId = bc.Id, PlayerId = c1.Id },
                new Goal { MatchId = bc.Id, PlayerId = c2.Id }
            );

            db.SaveChanges();

            Check(db.Teams.Count() == 4 && db.Players.Count() == 7,
                "Добавление и чтение данных через EF Core");

            var teamTop = LeagueService.BestScorers(db, 3, a.Id);

            Check(teamTop.Count == 3
                && teamTop[0].PlayerId == a1.Id
                && teamTop.Select(p => p.Goals)
                    .SequenceEqual(new[] { 2, 1, 1 }),
                "Топ-3 бомбардиров команды");

            Check(LeagueService.BestScorers(db, 1, a.Id)[0]
                .PlayerId == a1.Id,
                "Лучший бомбардир команды");

            var leagueTop = LeagueService.BestScorers(db, 3);

            Check(leagueTop.Count == 3
                && leagueTop[0].PlayerId == a1.Id
                && leagueTop[1].PlayerId == c1.Id,
                "Топ-3 бомбардиров чемпионата");

            Check(LeagueService.BestScorers(db, 1)[0]
                .PlayerId == a1.Id,
                "Лучший бомбардир чемпионата");

            Check(LeagueService.MostGoals(db, 3)
                .Select(t => t.TeamId)
                .SequenceEqual(new[] { a.Id, c.Id, b.Id }),
                "Топ-3 команд по забитым голам");

            Check(LeagueService.MostGoals(db, 1)[0].GoalsScored == 4,
                "Команда с максимумом забитых голов");

            Check(LeagueService.FewestConceded(db, 3)
                .Select(t => t.TeamId)
                .SequenceEqual(new[] { c.Id, d.Id, a.Id }),
                "Топ-3 команд по минимуму пропущенных");

            Check(LeagueService.FewestConceded(db, 1)[0]
                .TeamId == c.Id,
                "Команда с минимумом пропущенных голов");

            var table = db.Standings.ToList();

            Check(table.Single(t => t.TeamId == a.Id).Points == 4
                && table.Single(t => t.TeamId == b.Id).Points == 0
                && table.Single(t => t.TeamId == c.Id).Points == 4,
                "Три очка за победу и одно за ничью");

            Check(LeagueService.Points(db, 3, true)
                .Select(t => t.TeamId)
                .SequenceEqual(new[] { a.Id, c.Id, b.Id }),
                "Топ-3 команд по максимуму очков");

            Check(LeagueService.Points(db, 1, true)[0].TeamId == a.Id,
                "Лидер по очкам");

            Check(LeagueService.Points(db, 3, false)
                .Select(t => t.TeamId)
                .SequenceEqual(new[] { b.Id, d.Id, a.Id }),
                "Топ-3 команд по минимуму очков");

            Check(LeagueService.Points(db, 1, false)[0].TeamId == b.Id,
                "Команда с минимумом очков");

            LeagueService.Generate(db, DateTime.Today);

            Check(db.Matches.Count() == 6,
                "Процедура заполнила отсутствующие матчи");

            var players = db.Players.ToDictionary(p => p.Id);
            var goals = db.Goals.ToList();

            foreach (var match in db.Matches.ToList())
            {
                var matchGoals = goals
                    .Where(g => g.MatchId == match.Id).ToList();

                int home = matchGoals.Count(g =>
                    players[g.PlayerId].TeamId == match.HomeTeamId);

                int away = matchGoals.Count(g =>
                    players[g.PlayerId].TeamId == match.AwayTeamId);

                Check(match.HomeTeamId != match.AwayTeamId
                    && home == match.HomeGoals
                    && away == match.AwayGoals
                    && matchGoals.Count == home + away,
                    $"Счёт и авторы голов согласованы: матч {match.Id}");
            }

            int goalCount = db.Goals.Count();

            LeagueService.Generate(db, DateTime.Today);

            Check(db.Matches.Count() == 6
                && db.Goals.Count() == goalCount,
                "Повторная генерация не создаёт дубликаты");

            log.AppendLine();
            log.AppendLine("Все тесты пройдены.");

            return (true, log.ToString());
        }
        catch (Exception ex)
        {
            log.AppendLine();
            log.AppendLine("ОШИБКА: " + ex.GetBaseException().Message);

            return (false, log.ToString());
        }
        finally
        {
            // Удаляем только временную базу этого запуска тестов.
            if (created)
                db.Database.EnsureDeleted();
        }
    }
}
